#!/usr/bin/env lua
-- Generate subtitles for the timeline In/Out range, or the whole timeline when unmarked.

local SubFixGenerateSelectionCore = {}
local runtime_options = {}
local TARGET_SUBTITLE_TRACK = 1
local DEFAULT_ASR_MODEL = "large-v3-turbo"
local DEFAULT_ASR_LANGUAGE = tostring(os.getenv("SUBFIX_ASR_LANGUAGE") or "zh")
local DEFAULT_ASR_BACKEND = "auto"
local WORK_SCOPE_MODE_SELECTION = "selection"
local TRACK_CHECKED_MARK = "☑"
local TRACK_UNCHECKED_MARK = "☐"
local FALLBACK_ITEM_SCOPE_EXPAND_MAX_GAP_FRAMES = 2
local GENERATE_PROGRESS_BAR_WIDTH = 36
local GENERATE_PROGRESS_STALL_WARNING_SECONDS = 300
local GENERATE_BACKUP_PROGRESS_CHUNK_SIZE = 25
local GENERATE_UI_YIELD_INTERVAL_MS = 10
local GENERATE_WRITEBACK_OVERLAY_GEOMETRY = {120, 90, 1680, 880}

local fusion_app = fu or fusion
local ui = fusion_app and fusion_app.UIManager or nil
local dispatcher = (ui and bmd and bmd.UIDispatcher) and bmd.UIDispatcher(ui) or nil
local ui_timer_handlers = {}

if dispatcher and dispatcher.On then
    function dispatcher.On.Timeout(ev)
        local timer_id = tostring(ev and ev.who or "")
        local handler = ui_timer_handlers[timer_id]
        if handler then handler(ev) end
    end
end

local function shell_quote(value)
    local text = tostring(value or "")
    return "'" .. text:gsub("'", "'\\''") .. "'"
end

-- 模块可独立加载；复用全局命名空间也避免主脚本的 local 槽位上限。
SUBFIX_WINDOW_GEOMETRY = SUBFIX_WINDOW_GEOMETRY or {}

function SUBFIX_WINDOW_GEOMETRY.resolve_screen_bounds()
    if not (io and io.popen) then return nil end

    -- JXA 的返回值写入 stdout；console.log 写入 stderr，会被下面的重定向丢弃。
    local jxa = [[(function () {
    ObjC.import("AppKit");
    ObjC.import("CoreGraphics");
    const screens = $.NSScreen.screens;
    const primary = screens.objectAtIndex(0);
    const desktopTop = Number(primary.frame.origin.y) + Number(primary.frame.size.height);
    function screenRect(frame) {
        return {x: Number(frame.origin.x),
            y: desktopTop - Number(frame.origin.y) - Number(frame.size.height),
            width: Number(frame.size.width), height: Number(frame.size.height)};
    }
    let selected = primary;
    let mainWindow = null;
    let largestArea = 0;
    try {
        const raw = $.CGWindowListCopyWindowInfo(17, 0);
        const windows = ObjC.deepUnwrap(ObjC.castRefToObject(raw));
        for (const window of windows) {
            if (!/^(DaVinci Resolve|Resolve)$/i.test(String(window.kCGWindowOwnerName || ""))
                || Number(window.kCGWindowLayer) !== 0 || Number(window.kCGWindowAlpha) === 0) continue;
            const bounds = window.kCGWindowBounds;
            const area = bounds ? Number(bounds.Width) * Number(bounds.Height) : 0;
            if (area > largestArea) { largestArea = area; mainWindow = bounds; }
        }
    } catch (error) {
        // Window information may be unavailable; retain the primary display fallback.
    }
    if (mainWindow) {
        let largestOverlap = 0;
        for (let i = 0; i < Number(screens.count); i++) {
            const screen = screens.objectAtIndex(i);
            const rect = screenRect(screen.frame);
            const overlapWidth = Math.max(0, Math.min(rect.x + rect.width, Number(mainWindow.X) + Number(mainWindow.Width)) - Math.max(rect.x, Number(mainWindow.X)));
            const overlapHeight = Math.max(0, Math.min(rect.y + rect.height, Number(mainWindow.Y) + Number(mainWindow.Height)) - Math.max(rect.y, Number(mainWindow.Y)));
            const overlap = overlapWidth * overlapHeight;
            if (overlap > largestOverlap) { largestOverlap = overlap; selected = screen; }
        }
    }
    const visible = screenRect(selected.visibleFrame);
    return [visible.x, visible.y, visible.width, visible.height].join(",");
})();]]
    local escaped = jxa:gsub("'", "'\\\"'\\\"'")
    local pipe = io.popen("/usr/bin/osascript -l JavaScript -e '" .. escaped .. "' 2>/dev/null", "r")
    if not pipe then return nil end
    local output = pipe:read("*a") or ""
    pipe:close()
    local x, y, width, height = output:match("^%s*([%-%.%d]+),([%-%.%d]+),([%-%.%d]+),([%-%.%d]+)%s*$")
    x, y, width, height = tonumber(x), tonumber(y), tonumber(width), tonumber(height)
    if not x or not y or not width or not height or width <= 0 or height <= 0 then return nil end
    return {x = x, y = y, width = width, height = height}
end

function SUBFIX_WINDOW_GEOMETRY.centered_geometry(fallback_geometry)
    local fallback_x = tonumber(fallback_geometry and fallback_geometry[1])
    local fallback_y = tonumber(fallback_geometry and fallback_geometry[2])
    local width = tonumber(fallback_geometry and fallback_geometry[3])
    local height = tonumber(fallback_geometry and fallback_geometry[4])
    if not fallback_x or not fallback_y or not width or not height then return fallback_geometry end

    local screen = SUBFIX_WINDOW_GEOMETRY.resolve_screen_bounds()
    if not screen then return fallback_geometry end

    local x = screen.x
    local y = screen.y
    if width <= screen.width then x = math.floor(screen.x + (screen.width - width) / 2) end
    if height <= screen.height then y = math.floor(screen.y + (screen.height - height) / 2) end
    return {x, y, width, height}
end

local function read_text_file(path)
    local file = io.open(tostring(path or ""), "r")
    if not file then return nil end
    local content = file:read("*a")
    file:close()
    return content
end

local function write_text_file(path, content)
    local file = io.open(tostring(path or ""), "w")
    if not file then return false end
    local written = file:write(tostring(content or ""))
    local closed = file:close()
    return written ~= nil and closed ~= nil
end

local function json_escape(value)
    return tostring(value or "")
        :gsub("\\", "\\\\")
        :gsub('"', '\\"')
        :gsub("\n", "\\n")
        :gsub("\r", "\\r")
        :gsub("\t", "\\t")
end

local function get_checkbox_checked(item)
    if not item then return false end
    local attempts = {
        function() return item.Checked end,
        function() return item.CheckState end,
    }
    for _, getter in ipairs(attempts) do
        local ok, value = pcall(getter)
        if ok then
            if value == true or value == 1 then return true end
            local lowered = tostring(value or ""):lower()
            if lowered == "true" or lowered == "checked" or lowered == "1" then return true end
        end
    end
    return false
end

local function set_checkbox_checked(item, checked)
    if not item then return end
    local next_value = checked == true
    pcall(function() item.Checked = next_value end)
    pcall(function() item.CheckState = next_value and 1 or 0 end)
end

local function set_tree_item_text(item, column, text)
    pcall(function() item.Text[column] = tostring(text or "") end)
end

local function get_tree_event_value(ev, keys)
    for _, key in ipairs(keys or {}) do
        if ev and ev[key] ~= nil then return ev[key] end
    end
    return nil
end

local function get_selected_tree_node(tree)
    if not tree then return nil end
    local attempts = {
        function() return tree.CurrentItem end,
        function() return tree.SelectedItem end,
        function()
            local selected = tree:SelectedItems()
            return selected and selected[1] or nil
        end,
    }
    for _, getter in ipairs(attempts) do
        local ok, item = pcall(getter)
        if ok and item then return item end
    end
    return nil
end

local function safe_refresh_tree_widget(tree)
    if not tree then return end
    pcall(function() tree:Update() end)
    pcall(function() tree:Repaint() end)
end

local function trim_text(value)
    return tostring(value or ""):match("^%s*(.-)%s*$") or ""
end

local function decode_json_text(json_text)
    if type(json_text) ~= "string" or json_text == "" then return nil, "JSON 为空" end
    local pos = 1
    local len = #json_text
    local parse_value

    local function fail(msg)
        error(msg .. " at " .. tostring(pos), 0)
    end

    local function skip_ws()
        while pos <= len and json_text:sub(pos, pos):match("%s") do
            pos = pos + 1
        end
    end

    local function parse_string()
        if json_text:sub(pos, pos) ~= '"' then fail("expected string") end
        pos = pos + 1
        local parts = {}
        while pos <= len do
            local ch = json_text:sub(pos, pos)
            if ch == '"' then
                pos = pos + 1
                return table.concat(parts)
            elseif ch == "\\" then
                local esc = json_text:sub(pos + 1, pos + 1)
                local mapped = ({['"']='"', ["\\"]="\\", ["/"]="/", b="\b", f="\f", n="\n", r="\r", t="\t"})[esc]
                if mapped then
                    parts[#parts + 1] = mapped
                    pos = pos + 2
                elseif esc == "u" then
                    local code = tonumber(json_text:sub(pos + 2, pos + 5), 16)
                    parts[#parts + 1] = code and code < 128 and string.char(code) or "?"
                    pos = pos + 6
                else
                    fail("bad escape")
                end
            else
                parts[#parts + 1] = ch
                pos = pos + 1
            end
        end
        fail("unterminated string")
    end

    local function parse_number()
        local text = json_text:sub(pos):match("^%-?%d+%.?%d*[eE]?[%+%-]?%d*")
        if not text or text == "" then fail("expected number") end
        pos = pos + #text
        return tonumber(text)
    end

    local function parse_array()
        pos = pos + 1
        skip_ws()
        local result = {}
        if json_text:sub(pos, pos) == "]" then pos = pos + 1; return result end
        while true do
            result[#result + 1] = parse_value()
            skip_ws()
            local ch = json_text:sub(pos, pos)
            if ch == "," then
                pos = pos + 1
                skip_ws()
            elseif ch == "]" then
                pos = pos + 1
                return result
            else
                fail("expected array separator")
            end
        end
    end

    local function parse_object()
        pos = pos + 1
        skip_ws()
        local result = {}
        if json_text:sub(pos, pos) == "}" then pos = pos + 1; return result end
        while true do
            skip_ws()
            local key = parse_string()
            skip_ws()
            if json_text:sub(pos, pos) ~= ":" then fail("expected colon") end
            pos = pos + 1
            result[key] = parse_value()
            skip_ws()
            local ch = json_text:sub(pos, pos)
            if ch == "," then
                pos = pos + 1
                skip_ws()
            elseif ch == "}" then
                pos = pos + 1
                return result
            else
                fail("expected object separator")
            end
        end
    end

    parse_value = function()
        skip_ws()
        local ch = json_text:sub(pos, pos)
        if ch == '"' then return parse_string() end
        if ch == "{" then return parse_object() end
        if ch == "[" then return parse_array() end
        if ch == "t" and json_text:sub(pos, pos + 3) == "true" then pos = pos + 4; return true end
        if ch == "f" and json_text:sub(pos, pos + 4) == "false" then pos = pos + 5; return false end
        if ch == "n" and json_text:sub(pos, pos + 3) == "null" then pos = pos + 4; return nil end
        if ch == "-" or ch:match("%d") then return parse_number() end
        fail("unexpected JSON value")
    end

    local ok, result = pcall(function()
        local value = parse_value()
        skip_ws()
        return value
    end)
    if ok then return result end
    return nil, tostring(result)
end

local function file_exists(path)
    local file = io.open(tostring(path or ""), "rb")
    if file then
        file:close()
        return true
    end
    return false
end

local function register_ui_timer(timer, handler)
    if not timer or type(handler) ~= "function" then return false end
    local timer_id = tostring(timer.ID or "")
    if timer_id == "" then return false end
    ui_timer_handlers[timer_id] = handler
    return true
end

local function basename(path)
    local text = tostring(path or "")
    return text:match("([^/\\]+)$") or text
end

local function script_dir()
    local source = debug and debug.getinfo and debug.getinfo(1, "S").source or ""
    source = tostring(source or ""):gsub("^@", "")
    local dir = source:match("^(.*[/\\])")
    if dir and dir ~= "" then
        return dir:gsub("[/\\]$", "")
    end
    return os.getenv("PWD") or "."
end

local function configured_script_root()
    local root = runtime_options and runtime_options.script_root
    root = tostring(root or "")
    if root ~= "" then
        return root:gsub("[/\\]$", "")
    end
    return script_dir()
end

local function resolve_asr_paths()
    local root = configured_script_root()
    local helper_dir = root .. "/.subfix_support"
    local home_dir = os.getenv("HOME") or ""
    local user_support_dir = home_dir ~= "" and (home_dir .. "/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Scripts/Utility/.subfix_support") or helper_dir
    local user_python = user_support_dir .. "/.subfix_asr_env/bin/python"
    local user_runtime_python = user_support_dir .. "/runtime/python/bin/python3"
    local paths = {
        helper = helper_dir .. "/subfix_asr_transcribe.py",
        qwen_manager = helper_dir .. "/subfix_model_manager.py",
        process_group = helper_dir .. "/subfix_process_group.py",
        setup = helper_dir .. "/setup_asr_env.sh",
        python = helper_dir .. "/.subfix_asr_env/bin/python",
        runtime_python = helper_dir .. "/runtime/python/bin/python3",
        diagnostic = user_support_dir .. "/last_generate_diagnostic.json",
        generation_history = user_support_dir .. "/generation_history",
        plugin_source = root .. "/SubFix.lua",
        generation_core_source = script_dir() .. "/subfix_generate_selection_core.lua",
        reference_base = user_support_dir .. "/subfix_generate_reference",
        hotwords = user_support_dir .. "/hotwords.json"
    }
    if not file_exists(paths.plugin_source) and file_exists(root .. "/SubFix/SubFix.lua") then
        paths.plugin_source = root .. "/SubFix/SubFix.lua"
    end
    if not file_exists(paths.helper) and file_exists(root .. "/subfix_asr_transcribe.py") then
        paths.helper = root .. "/subfix_asr_transcribe.py"
        paths.qwen_manager = root .. "/subfix_model_manager.py"
        paths.process_group = root .. "/subfix_process_group.py"
        paths.setup = root .. "/setup_asr_env.sh"
        paths.python = root .. "/.subfix_asr_env/bin/python"
        paths.runtime_python = root .. "/runtime/python/bin/python3"
    end
    local module_dir = script_dir()
    if not file_exists(paths.helper) and file_exists(module_dir .. "/subfix_asr_transcribe.py") then
        paths.helper = module_dir .. "/subfix_asr_transcribe.py"
        paths.qwen_manager = module_dir .. "/subfix_model_manager.py"
        paths.process_group = module_dir .. "/subfix_process_group.py"
        paths.setup = module_dir .. "/setup_asr_env.sh"
        paths.python = module_dir .. "/.subfix_asr_env/bin/python"
        paths.runtime_python = module_dir .. "/runtime/python/bin/python3"
    end
    if not file_exists(paths.python) and file_exists(user_python) then
        paths.python = user_python
    end
    if not file_exists(paths.runtime_python) and file_exists(user_runtime_python) then
        paths.runtime_python = user_runtime_python
    end
    return paths
end

local function build_qwen_status_command(paths, output_path)
    if not paths or not file_exists(paths.runtime_python) or not file_exists(paths.qwen_manager) then
        return nil, "模型中心组件缺失，请安装最新完整 SubFix 安装包"
    end
    return table.concat({
        "env", "PYTHONDONTWRITEBYTECODE=1", shell_quote(paths.runtime_python), "-B", shell_quote(paths.qwen_manager),
        "--action", "status", "--output", shell_quote(output_path),
    }, " "), nil
end

local function inspect_local_qwen(paths)
    local temporary_root = os.getenv("TMPDIR") or "/tmp"
    local output_path = temporary_root .. "/subfix_qwen_status_" .. tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999)) .. ".json"
    local cmd = build_qwen_status_command(paths, output_path)
    if not cmd then return {state = "missing", ready = false} end
    os.execute(cmd .. " >/dev/null 2>&1")
    local payload = decode_json_text(read_text_file(output_path) or "")
    os.execute("rm -f " .. shell_quote(output_path) .. " 2>/dev/null")
    if type(payload) ~= "table" then return {state = "missing", ready = false} end
    payload.ready = payload.ready == true
    return payload
end

-- 豆包（火山引擎）云端 ASR 密钥文件路径：必须与「实际被执行的」
-- subfix_asr_transcribe.py 同目录，才能与 Python 端
-- _doubao_credentials_path()（Path(__file__).with_name(...)）指向一致，
-- 保证 UI 写盘后立即可读、无需再跑 sync。
local function doubao_credentials_file_path()
    local helper = tostring(resolve_asr_paths().helper or "")
    local dir = helper:gsub("/[^/]*$", "")
    if dir == "" or dir == helper then
        dir = configured_script_root() .. "/.subfix_support"
    end
    return dir .. "/doubao_credentials.json"
end

-- 读回已存 API Key（缺失/解析失败/字段空 → 返回空串），用于单字段预填。
local function read_doubao_api_key()
    local text = read_text_file(doubao_credentials_file_path())
    if not text or text == "" then return "" end
    local data = decode_json_text(text)
    if type(data) ~= "table" then return "" end
    return trim_text(tostring(data.api_key or ""))
end

-- 是否已配置豆包密钥：仅接受 API Key，旧 appid/token 永不视为有效。
local function doubao_credentials_configured()
    local env_api_key = trim_text(os.getenv("SUBFIX_DOUBAO_API_KEY") or "")
    if env_api_key ~= "" then return true end
    local api_key = read_doubao_api_key()
    return api_key ~= ""
end

-- 保存单 API Key；覆盖旧格式，防止界面再次回到两字段。
local function save_doubao_api_key(api_key)
    local content = string.format('{\n  "api_key": "%s"\n}\n', json_escape(api_key))
    local path = doubao_credentials_file_path()
    if not write_text_file(path, content) then
        return false, "无法写入密钥文件: " .. path
    end
    return true
end

-- 生成偏好文件（记住上次选的识别模型等），与 helper 同级。
local function generate_prefs_file_path()
    local helper = tostring(resolve_asr_paths().helper or "")
    local dir = helper:gsub("/[^/]*$", "")
    if dir == "" or dir == helper then
        dir = configured_script_root() .. "/.subfix_support"
    end
    return dir .. "/subfix_generate_prefs.json"
end

local function normalize_doubao_backend(backend)
    if trim_text(tostring(backend or "")) == "doubao_asr_v2" then
        return "doubao_asr_v2"
    end
    return "doubao_asr"
end

local function read_generate_preferences()
    local text = read_text_file(generate_prefs_file_path())
    local data = text and text ~= "" and decode_json_text(text) or nil
    return type(data) == "table" and data or {}
end

-- 读上次选择的识别模型 backend（无偏好/解析失败 → nil）。
local function read_last_engine_backend()
    local data = read_generate_preferences()
    local b = trim_text(tostring(data.last_engine_backend or ""))
    return b ~= "" and b or nil
end

-- 兼容旧偏好：V2 保留，其余值（含缺失/未知）默认极速版。
local function read_doubao_backend_preference()
    local data = read_generate_preferences()
    return normalize_doubao_backend(data.doubao_backend or data.last_engine_backend)
end

local function write_generate_preferences(data)
    data = type(data) == "table" and data or {}
    local last_engine_backend = trim_text(tostring(data.last_engine_backend or ""))
    local doubao_backend = normalize_doubao_backend(data.doubao_backend)
    local selected_audio_tracks = {}
    for _, track_index in ipairs(type(data.selected_audio_tracks) == "table" and data.selected_audio_tracks or {}) do
        if type(track_index) == "number" and track_index > 0 and track_index % 1 == 0 then
            selected_audio_tracks[#selected_audio_tracks + 1] = tostring(track_index)
        end
    end
    local audio_track_count = tonumber(data.audio_track_count)
    if not audio_track_count or audio_track_count < 1 or audio_track_count % 1 ~= 0 then
        audio_track_count = nil
    end
    local content = string.format(
        '{\n  "last_engine_backend": "%s",\n  "doubao_backend": "%s",\n  "max_chars": %d,\n  "hotwords_enabled": %s,\n  "audio_track_count": %s,\n  "selected_audio_tracks": [%s]\n}\n',
        json_escape(last_engine_backend),
        json_escape(doubao_backend),
        tonumber(data.max_chars) == 10 and 10 or 25,
        type(data.hotwords_enabled) == "boolean" and tostring(data.hotwords_enabled) or "null",
        audio_track_count and tostring(audio_track_count) or "null",
        table.concat(selected_audio_tracks, ",")
    )
    return write_text_file(generate_prefs_file_path(), content)
end

-- 生成时一并保存长度/热词/轨道选择；仅切换模型时保留已有选择。
local function save_last_engine_backend(backend, max_chars, hotwords_enabled, audio_track_count, selected_audio_tracks)
    local data = read_generate_preferences()
    data.doubao_backend = read_doubao_backend_preference()
    data.last_engine_backend = backend
    if max_chars ~= nil then data.max_chars = max_chars end
    if type(hotwords_enabled) == "boolean" then data.hotwords_enabled = hotwords_enabled end
    if audio_track_count ~= nil and type(selected_audio_tracks) == "table" then
        data.audio_track_count = audio_track_count
        data.selected_audio_tracks = selected_audio_tracks
    end
    return write_generate_preferences(data)
end

local function save_doubao_backend_preference(backend)
    local data = read_generate_preferences()
    data.doubao_backend = normalize_doubao_backend(backend)
    return write_generate_preferences(data)
end

local function project_reference_path(project)
    local ok, id = pcall(function() return project:GetUniqueId() end)
    if not ok or type(id) ~= "string" or trim_text(id) == "" then return nil end
    -- 按字节编码，让不同项目 ID 在大小写不敏感的文件系统上也各有一份。
    local key = id:gsub(".", function(byte) return string.format("%02x", byte:byte()) end)
    return resolve_asr_paths().reference_base .. "." .. key .. ".json"
end

local function read_generate_reference(path)
    if not path then return nil end
    local raw = read_text_file(path)
    local data = raw and decode_json_text(raw)
    if type(data) == "table" and type(data.text) == "string" and type(data.enabled) == "boolean" then
        return data
    end
end

local function write_generate_reference(path, text, enabled)
    local pipe = io.popen("/usr/bin/mktemp " .. shell_quote(path .. ".XXXXXX") .. " 2>/dev/null", "r")
    if not pipe then return false end
    local temp = pipe:read("*l")
    pipe:close()
    if not temp or temp == "" then return false end
    local escaped = json_escape(text):gsub("[%z\1-\31]", function(c)
        return string.format("\\u%04x", string.byte(c))
    end)
    local content = string.format('{"enabled":%s,"text":"%s"}\n', tostring(enabled), escaped)
    if write_text_file(temp, content) and os.rename(temp, path) then return true end
    os.remove(temp)
    return false
end

local function load_generate_hotword_entries()
    local text = read_text_file(resolve_asr_paths().hotwords)
    local payload = text and decode_json_text(text) or nil
    local raw_entries = type(payload) == "table" and payload.entries or {}
    if type(raw_entries) ~= "table" then return {} end
    local entries, seen_terms = {}, {}
    for _, raw_entry in ipairs(raw_entries) do
        if type(raw_entry) == "table" then
            local term = trim_text(tostring(raw_entry.term or ""))
            if term ~= "" and not seen_terms[term] then
                local aliases, seen_aliases = {}, {}
                if type(raw_entry.aliases) == "table" then
                    for _, raw_alias in ipairs(raw_entry.aliases) do
                        local alias = trim_text(tostring(raw_alias or ""))
                        if alias ~= "" and alias ~= term and not seen_aliases[alias] then
                            aliases[#aliases + 1] = alias
                            seen_aliases[alias] = true
                        end
                    end
                end
                entries[#entries + 1] = {term = term, aliases = aliases}
                seen_terms[term] = true
            end
        end
    end
    return entries
end

local function save_generate_hotword_entries(entries)
    local path = resolve_asr_paths().hotwords
    local parts = {}
    for _, entry in ipairs(entries or {}) do
        local aliases = {}
        for _, alias in ipairs(entry.aliases or {}) do
            aliases[#aliases + 1] = '"' .. json_escape(alias) .. '"'
        end
        parts[#parts + 1] = string.format(
            '{"term":"%s","aliases":[%s]}',
            json_escape(entry.term),
            table.concat(aliases, ",")
        )
    end
    return write_text_file(path, '{"version":1,"entries":[' .. table.concat(parts, ",") .. "]}\n")
end

local function temp_dir()
    local root = (os.getenv("TMPDIR") or "/tmp") .. "/SubFix_GenerateSelectionSubtitles"
    os.execute("mkdir -p " .. shell_quote(root) .. " 2>/dev/null")
    return root
end

local function parse_fps(value)
    local text = tostring(value or "")
    if text == "29.97" then return 30000 / 1001 end
    if text == "23.976" or text == "23.98" then return 24000 / 1001 end
    if text == "59.94" then return 60000 / 1001 end
    local fps = tonumber(value)
    if fps and fps > 0 then return fps end
    print(string.format("[SubFix Generate] 无法解析时间线帧率 %q，回退 30.0", text))
    return 30.0
end

local function frames_to_srt_time(frame, fps, base_frame)
    local rel_frame = math.max(0, (tonumber(frame) or 0) - (tonumber(base_frame) or 0))
    local ms = math.floor((rel_frame / math.max(1, tonumber(fps) or 30)) * 1000 + 0.5)
    local hours = math.floor(ms / 3600000)
    ms = ms % 3600000
    local minutes = math.floor(ms / 60000)
    ms = ms % 60000
    local seconds = math.floor(ms / 1000)
    local millis = ms % 1000
    return string.format("%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
end

local function frames_to_timecode(frame, fps)
    local rate = math.max(1, tonumber(fps) or 30)
    local fps_int = math.max(1, math.floor(rate + 0.5))
    local frames = math.max(0, math.floor(tonumber(frame) or 0))
    local total_seconds = frames / rate
    local hours = math.floor(total_seconds / 3600)
    local remaining = total_seconds % 3600
    local minutes = math.floor(remaining / 60)
    local seconds = math.floor(remaining % 60)
    local ff = frames - math.floor((hours * 3600 + minutes * 60 + seconds) * rate)
    ff = math.max(0, math.min(ff, fps_int - 1))
    return string.format("%02d:%02d:%02d:%02d", hours, minutes, seconds, ff)
end

local function timecode_to_frame(value, fps)
    local hh, mm, ss, ff = tostring(value or ""):match("^(%d+):(%d+):(%d+)[:;](%d+)$")
    if not hh then return nil end
    local rate = math.max(1, tonumber(fps) or 30)
    local total_seconds = (tonumber(hh) or 0) * 3600 + (tonumber(mm) or 0) * 60 + (tonumber(ss) or 0)
    return math.floor(total_seconds * rate + (tonumber(ff) or 0) + 0.5)
end

local function srt_time_to_frame(value, fps, base_frame)
    local hh, mm, ss, ms = tostring(value or ""):match("^(%d+):(%d+):(%d+),(%d+)$")
    if not hh then return nil end
    local total_ms = ((tonumber(hh) or 0) * 3600 + (tonumber(mm) or 0) * 60 + (tonumber(ss) or 0)) * 1000 + (tonumber(ms) or 0)
    return math.floor((total_ms / 1000) * math.max(1, tonumber(fps) or 30) + 0.5) + (tonumber(base_frame) or 0)
end

local function get_resolve()
    if resolve then return resolve end
    if bmd and bmd.scriptapp then
        return bmd.scriptapp("Resolve")
    end
    return nil
end

local function get_mark_value(mark, kind)
    if type(mark) ~= "table" then return nil end
    local keys = kind == "in"
        and {"in", "markIn", "mark_in", "MarkIn", "start", "Start", "startFrame", "start_frame", 1}
        or {"out", "markOut", "mark_out", "MarkOut", "end", "End", "endFrame", "end_frame", 2}
    for _, key in ipairs(keys) do
        if mark[key] ~= nil then return mark[key] end
    end
    return nil
end

local function normalize_mark_frame(value, timeline_start, timeline_end, fps)
    local parsed_from_timecode = false
    local frame = tonumber(value)
    if not frame then
        frame = timecode_to_frame(value, fps)
        parsed_from_timecode = frame ~= nil
    end
    if not frame then return nil end
    local start_frame = tonumber(timeline_start) or 0
    local end_frame = tonumber(timeline_end)
    if parsed_from_timecode then
        if end_frame and frame >= start_frame and frame <= end_frame then
            return math.floor(frame + 0.5)
        end
        local shifted_timecode_frame = frame + start_frame
        if end_frame and shifted_timecode_frame >= start_frame and shifted_timecode_frame <= end_frame then
            return math.floor(shifted_timecode_frame + 0.5)
        end
        return math.floor(frame + 0.5)
    end
    local shifted_frame = frame + start_frame

    -- Resolve may return In/Out as elapsed timeline frames on timelines that start
    -- at 01:00:00. Prefer the shifted candidate when it still lands on the timeline;
    -- this mirrors SubFix's "absolute rows, relative SRT" writeback model and avoids
    -- the classic one-hour-left placement.
    if end_frame and start_frame > 0 and shifted_frame >= start_frame and shifted_frame <= end_frame then
        return math.floor(shifted_frame + 0.5)
    end
    if end_frame and frame >= start_frame and frame <= end_frame then
        return math.floor(frame + 0.5)
    end
    return math.floor(shifted_frame + 0.5)
end

local timeline_item_is_selected

local function get_timeline_frame_bounds(timeline)
    local ok_start, timeline_start = pcall(function() return timeline:GetStartFrame() end)
    local ok_end, timeline_end = pcall(function() return timeline:GetEndFrame() end)
    timeline_start = ok_start and tonumber(timeline_start) or nil
    timeline_end = ok_end and tonumber(timeline_end) or nil
    return timeline_start, timeline_end
end

local function get_timeline_item_name(item)
    local ok_name, raw_name = pcall(function() return item:GetName() end)
    local name = ok_name and trim_text(raw_name) or ""
    if name ~= "" then return name end
    local ok_media, media_item = pcall(function() return item:GetMediaPoolItem() end)
    if ok_media and media_item then
        local ok_clip_name, raw_clip_name = pcall(function() return media_item:GetClipProperty("Clip Name") end)
        name = ok_clip_name and trim_text(raw_clip_name) or ""
        if name ~= "" then return name end
    end
    return ""
end

local function get_timeline_item_media_key(item)
    local ok_media, media_item = pcall(function() return item:GetMediaPoolItem() end)
    if ok_media and media_item then
        local ok_path, raw_path = pcall(function() return media_item:GetClipProperty("File Path") end)
        local path = ok_path and trim_text(raw_path) or ""
        if path ~= "" then return "path:" .. path end
        local ok_clip_name, raw_clip_name = pcall(function() return media_item:GetClipProperty("Clip Name") end)
        local clip_name = ok_clip_name and trim_text(raw_clip_name) or ""
        if clip_name ~= "" then return "clip:" .. clip_name end
    end
    local item_name = get_timeline_item_name(item)
    if item_name ~= "" then return "item:" .. item_name end
    return nil
end

local function build_timeline_item_scope(source, source_label, start_frame, end_frame, timeline_start, timeline_end, item_name)
    start_frame = tonumber(start_frame)
    end_frame = tonumber(end_frame)
    if not start_frame or not end_frame or end_frame <= start_frame then return nil end
    return {
        mode = WORK_SCOPE_MODE_SELECTION,
        source = source,
        source_label = source_label,
        start_frame = math.floor(start_frame + 0.5),
        end_frame = math.floor(end_frame + 0.5),
        timeline_start_frame = tonumber(timeline_start) or 0,
        timeline_end_frame = tonumber(timeline_end) or tonumber(timeline_start) or 0,
        item_name = item_name
    }
end

local function expand_scope_from_seed_item(timeline, track_type, track_index, seed_item, seed_start, seed_end)
    local seed_key = get_timeline_item_media_key(seed_item)
    if not seed_key or seed_key == "" then
        return tonumber(seed_start), tonumber(seed_end), 1
    end
    local ok_items, items = pcall(function() return timeline:GetItemListInTrack(track_type, track_index) end)
    items = ok_items and items or {}
    local records = {}
    local seed_record_index = nil
    for item_index, item in ipairs(items or {}) do
        local ok_start, item_start = pcall(function() return item:GetStart() end)
        local ok_end, item_end = pcall(function() return item:GetEnd() end)
        item_start = ok_start and tonumber(item_start) or nil
        item_end = ok_end and tonumber(item_end) or nil
        if item_start and item_end and item_end > item_start then
            local record = {
                item = item,
                item_index = item_index,
                start_frame = item_start,
                end_frame = item_end,
                media_key = get_timeline_item_media_key(item)
            }
            records[#records + 1] = record
            if item == seed_item or (
                item_start == tonumber(seed_start)
                and item_end == tonumber(seed_end)
                and not seed_record_index
            ) then
                seed_record_index = #records
            end
        end
    end
    if not seed_record_index then
        return tonumber(seed_start), tonumber(seed_end), 1
    end
    table.sort(records, function(a, b)
        if a.start_frame ~= b.start_frame then return a.start_frame < b.start_frame end
        return (tonumber(a.item_index) or 0) < (tonumber(b.item_index) or 0)
    end)
    for index, record in ipairs(records) do
        if record.item == seed_item or (
            record.start_frame == tonumber(seed_start)
            and record.end_frame == tonumber(seed_end)
        ) then
            seed_record_index = index
            break
        end
    end
    local first_index = seed_record_index
    local last_index = seed_record_index
    local max_gap = tonumber(FALLBACK_ITEM_SCOPE_EXPAND_MAX_GAP_FRAMES) or 0
    while first_index > 1 do
        local prev = records[first_index - 1]
        local current = records[first_index]
        local gap = current.start_frame - prev.end_frame
        if prev.media_key ~= seed_key or gap < 0 or gap > max_gap then break end
        first_index = first_index - 1
    end
    while last_index < #records do
        local current = records[last_index]
        local next_record = records[last_index + 1]
        local gap = next_record.start_frame - current.end_frame
        if next_record.media_key ~= seed_key or gap < 0 or gap > max_gap then break end
        last_index = last_index + 1
    end
    return records[first_index].start_frame, records[last_index].end_frame, (last_index - first_index + 1)
end

local function read_timeline_in_out_scope(timeline, fps, timeline_start, timeline_end)
    local ok_marks, marks = pcall(function() return timeline:GetMarkInOut() end)
    if not ok_marks or (marks ~= nil and type(marks) ~= "table") then
        return nil, "无法读取时间线 In/Out 标记"
    end
    if marks == nil then return nil end
    local has_marks = false
    local mark_candidates = {}
    if marks.video ~= nil then mark_candidates[#mark_candidates + 1] = marks.video end
    if marks.audio ~= nil then mark_candidates[#mark_candidates + 1] = marks.audio end
    if marks.all ~= nil then mark_candidates[#mark_candidates + 1] = marks.all end
    mark_candidates[#mark_candidates + 1] = marks
    for _, mark in ipairs(mark_candidates) do
        local mark_in = get_mark_value(mark, "in")
        local mark_out = get_mark_value(mark, "out")
        local source_label = "In/Out"
        if mark_in == nil and mark_out ~= nil then
            mark_in = timeline_start
            source_label = "In/Out (Out only)"
        elseif mark_in ~= nil and mark_out == nil then
            mark_out = timeline_end
            source_label = "In/Out (In only)"
        end
        if mark_in ~= nil and mark_out ~= nil then
            has_marks = true
            local start_frame = normalize_mark_frame(mark_in, timeline_start, timeline_end, fps)
            local end_frame = normalize_mark_frame(mark_out, timeline_start, timeline_end, fps)
            if source_label == "In/Out (Out only)" then
                start_frame = timeline_start
            elseif source_label == "In/Out (In only)" then
                end_frame = timeline_end
            end
            if start_frame and end_frame and end_frame > start_frame then
                print(string.format(
                    "[SubFix Generate] In/Out raw=%s-%s timeline_start=%s normalized=%s-%s",
                    tostring(mark_in),
                    tostring(mark_out),
                    tostring(timeline_start),
                    tostring(start_frame),
                    tostring(end_frame)
                ))
                return {
                    mode = WORK_SCOPE_MODE_SELECTION,
                    source = "in_out",
                    source_label = source_label,
                    start_frame = start_frame,
                    end_frame = end_frame,
                    timeline_start_frame = timeline_start,
                    timeline_end_frame = timeline_end
                }
            end
        end
    end
    if has_marks then return nil, "In/Out 范围无效，请检查时间线标记" end
    return nil
end

local function read_selected_timeline_item_scope(timeline)
    local timeline_start, timeline_end = get_timeline_frame_bounds(timeline)
    local selected_start = nil
    local selected_end = nil
    local selected_count = 0
    local selected_names = {}
    local track_types = {"video", "audio"}
    for _, track_type in ipairs(track_types) do
        local ok_track_count, track_count = pcall(function() return timeline:GetTrackCount(track_type) end)
        track_count = ok_track_count and tonumber(track_count) or 0
        for track_index = 1, track_count do
            local ok_items, items = pcall(function() return timeline:GetItemListInTrack(track_type, track_index) end)
            items = ok_items and items or {}
            for _, item in ipairs(items or {}) do
                if timeline_item_is_selected and timeline_item_is_selected(item) then
                    local ok_start, item_start = pcall(function() return item:GetStart() end)
                    local ok_end, item_end = pcall(function() return item:GetEnd() end)
                    item_start = ok_start and tonumber(item_start) or nil
                    item_end = ok_end and tonumber(item_end) or nil
                    if item_start and item_end and item_end > item_start then
                        local expanded_start, expanded_end, expanded_count = expand_scope_from_seed_item(
                            timeline,
                            track_type,
                            track_index,
                            item,
                            item_start,
                            item_end
                        )
                        selected_start = selected_start and math.min(selected_start, expanded_start or item_start) or (expanded_start or item_start)
                        selected_end = selected_end and math.max(selected_end, expanded_end or item_end) or (expanded_end or item_end)
                        selected_count = selected_count + 1
                        local item_name = get_timeline_item_name(item)
                        if item_name ~= "" and #selected_names < 3 then selected_names[#selected_names + 1] = item_name end
                        if (tonumber(expanded_count) or 1) > 1 then
                            print(string.format(
                                "[SubFix Generate] 选中片段已按相邻同素材扩展 track=%s:%d %s-%s -> %s-%s count=%d",
                                tostring(track_type),
                                track_index,
                                tostring(item_start),
                                tostring(item_end),
                                tostring(expanded_start),
                                tostring(expanded_end),
                                tonumber(expanded_count) or 1
                            ))
                        end
                    end
                end
            end
        end
    end
    if selected_start and selected_end and selected_end > selected_start then
        print(string.format(
            "[SubFix Generate] 未读到 I/O，使用 Resolve 可读的选中片段范围 %s-%s count=%d",
            tostring(selected_start),
            tostring(selected_end),
            selected_count
        ))
        return build_timeline_item_scope(
            "selected_timeline_items",
            "选中片段",
            selected_start,
            selected_end,
            timeline_start,
            timeline_end,
            table.concat(selected_names, " / ")
        )
    end
    return nil, "Resolve 脚本 API 未返回可读的选中片段"
end

local function find_playhead_item_scope_in_track_type(timeline, fps, track_type, source_label)
    local ok_timecode, current_timecode = pcall(function() return timeline:GetCurrentTimecode() end)
    local playhead_frame = ok_timecode and timecode_to_frame(current_timecode, fps) or nil
    if not playhead_frame then return nil, "无法读取当前播放头时间码" end
    local timeline_start, timeline_end = get_timeline_frame_bounds(timeline)
    playhead_frame = normalize_mark_frame(playhead_frame, timeline_start, timeline_end)
    local ok_track_count, track_count = pcall(function() return timeline:GetTrackCount(track_type) end)
    track_count = ok_track_count and tonumber(track_count) or 0
    local best_item = nil
    for track_index = 1, track_count do
        local ok_items, items = pcall(function() return timeline:GetItemListInTrack(track_type, track_index) end)
        items = ok_items and items or {}
        for item_index, item in ipairs(items or {}) do
            local ok_start, item_start = pcall(function() return item:GetStart() end)
            local ok_end, item_end = pcall(function() return item:GetEnd() end)
            item_start = ok_start and tonumber(item_start) or nil
            item_end = ok_end and tonumber(item_end) or nil
            if item_start and item_end and item_start <= playhead_frame and playhead_frame < item_end then
                local duration = item_end - item_start
                if duration > 0 and (
                    not best_item
                    or duration > best_item.duration
                    or (duration == best_item.duration and track_index < best_item.track_index)
                    or (duration == best_item.duration and track_index == best_item.track_index and item_index < best_item.item_index)
                ) then
                    best_item = {
                        item = item,
                        item_start = item_start,
                        item_end = item_end,
                        duration = duration,
                        track_index = track_index,
                        item_index = item_index
                    }
                end
            end
        end
    end
    if best_item then
        local item_name = get_timeline_item_name(best_item.item)
        local expanded_start, expanded_end, expanded_count = expand_scope_from_seed_item(
            timeline,
            track_type,
            best_item.track_index,
            best_item.item,
            best_item.item_start,
            best_item.item_end
        )
        expanded_start = expanded_start or best_item.item_start
        expanded_end = expanded_end or best_item.item_end
        print(string.format(
            "[SubFix Generate] 未读到 I/O，使用播放头所在%s片段 %s-%s track=%d item=%d，扩展后 %s-%s count=%d",
            track_type,
            tostring(best_item.item_start),
            tostring(best_item.item_end),
            best_item.track_index,
            best_item.item_index,
            tostring(expanded_start),
            tostring(expanded_end),
            tonumber(expanded_count) or 1
        ))
        return build_timeline_item_scope(
            "playhead_" .. track_type .. "_item",
            source_label,
            expanded_start,
            expanded_end,
            timeline_start,
            timeline_end,
            item_name
        )
    end
    return nil, "播放头不在任何" .. tostring(source_label) .. "内"
end

local function read_playhead_timeline_item_scope(timeline, fps)
    local scope = find_playhead_item_scope_in_track_type(timeline, fps, "video", "播放头所在视频片段")
    if scope then return scope end
    return find_playhead_item_scope_in_track_type(timeline, fps, "audio", "播放头所在音频片段")
end

local function read_generation_scope(timeline, fps)
    local first, last = get_timeline_frame_bounds(timeline)
    if not first or not last then return nil, "无法读取时间线起止帧" end
    if last <= first then return nil, "时间线为空，没有可识别的音频" end
    local scope, err = read_timeline_in_out_scope(timeline, fps, first, last)
    if scope or err then return scope, err end
    return build_timeline_item_scope("full_timeline", "整条时间线", first, last, first, last)
end

local function get_audio_item_source_offset_frames(item, timeline_fps)
    local ok_source_start, source_start_frames = pcall(function() return item:GetSourceStartFrame() end)
    local offset = ok_source_start and tonumber(source_start_frames) or nil
    local ok_source_fps, source_fps = pcall(function() return item:GetMediaPoolItem():GetClipProperty("FPS") end)
    source_fps = ok_source_fps and tonumber(source_fps) or nil
    -- Source start uses media frames; GetLeftOffset uses timeline frames.
    if offset and offset >= 0 and source_fps and source_fps > 0 then return offset, source_fps end
    local ok_left_offset, left_offset_frames = pcall(function() return item:GetLeftOffset(false) end)
    if not ok_left_offset then
        ok_left_offset, left_offset_frames = pcall(function() return item:GetLeftOffset() end)
    end
    offset = ok_left_offset and tonumber(left_offset_frames) or 0
    if not offset or offset < 0 then offset = 0 end
    return offset, timeline_fps
end

local function get_audio_item_file_path(item)
    local ok_media, media_item = pcall(function() return item:GetMediaPoolItem() end)
    if not ok_media or not media_item then return nil end
    local ok_path, raw_path = pcall(function() return media_item:GetClipProperty("File Path") end)
    if ok_path and raw_path and tostring(raw_path) ~= "" then
        local file_path = tostring(raw_path)
        if file_exists(file_path) then return file_path end
    end
    return nil
end

local function parse_source_audio_channel_mapping(item, media_item, fps, source_offset_frames, fallback_path)
    local result = {
        file_path = fallback_path,
        audio_mapping_source = "media_pool_file",
        audio_mapping_fallback_reason = "",
        linked_offset_samples = nil,
        audio_channel_index = nil,
        audio_mapping_muted = false
    }
    if not item then
        result.audio_mapping_fallback_reason = "mapping_item_missing"
        return result
    end

    local ok_mapping, raw_mapping = pcall(function() return item:GetSourceAudioChannelMapping() end)
    if not ok_mapping or not raw_mapping or tostring(raw_mapping) == "" then
        result.audio_mapping_fallback_reason = ok_mapping and "mapping_empty" or "mapping_api_unavailable"
        return result
    end

    local mapping = decode_json_text(tostring(raw_mapping))
    if type(mapping) ~= "table" then
        result.audio_mapping_fallback_reason = "mapping_json_error"
        return result
    end

    local track_mapping = mapping.track_mapping or {}
    local mapped_track = track_mapping[tostring(1)] or track_mapping[1]
    if type(mapped_track) ~= "table" then
        for _, candidate in pairs(track_mapping) do
            if type(candidate) == "table" then
                mapped_track = candidate
                break
            end
        end
    end
    if type(mapped_track) ~= "table" then
        result.audio_mapping_fallback_reason = "track_mapping_missing"
        return result
    end

    local channel_idx = nil
    if type(mapped_track.channel_idx) == "table" then
        channel_idx = tonumber(mapped_track.channel_idx[1])
    end
    result.audio_mapping_muted = mapped_track.mute == true
        or tostring(mapped_track.mute or "") == "1"
        or tostring(mapped_track.mute or ""):lower() == "true"
    local linked_audio = mapping.linked_audio or {}
    local embedded_count = tonumber(mapping.embedded_audio_channels) or 0
    local linked_channel_number = channel_idx and (channel_idx - embedded_count) or nil
    local linked_keys = {}
    for key, _ in pairs(linked_audio) do
        linked_keys[#linked_keys + 1] = key
    end
    table.sort(linked_keys, function(a, b) return tonumber(a) < tonumber(b) end)

    local linked_info = nil
    local linked_key = nil
    local linked_local_channel_index = nil
    if linked_channel_number and linked_channel_number > 0 then
        local remaining_channel = linked_channel_number
        for _, key in ipairs(linked_keys) do
            local candidate = linked_audio[key]
            local candidate_channels = tonumber(candidate and candidate.channels) or 1
            if remaining_channel <= candidate_channels then
                linked_info = candidate
                linked_key = key
                linked_local_channel_index = remaining_channel
                break
            end
            remaining_channel = remaining_channel - candidate_channels
        end
    end
    if type(linked_info) ~= "table" or not linked_info.path or tostring(linked_info.path) == "" then
        result.audio_mapping_fallback_reason = "linked_audio_missing"
        return result
    end

    local linked_path = tostring(linked_info.path)
    if not file_exists(linked_path) then
        result.audio_mapping_fallback_reason = "linked_audio_not_found"
        return result
    end

    local sample_rate = 48000
    if media_item then
        local ok_sample_rate, raw_sample_rate = pcall(function() return media_item:GetClipProperty("Sample Rate") end)
        sample_rate = tonumber(ok_sample_rate and raw_sample_rate) or sample_rate
    end
    local linked_offset_samples = tonumber(linked_info.offset) or 0
    local effective_fps = math.max(1, tonumber(fps) or 30)
    local source_frames = math.max(0, tonumber(source_offset_frames) or 0)
    result.file_path = linked_path
    result.audio_mapping_source = "linked_audio"
    result.audio_mapping_fallback_reason = ""
    result.linked_offset_samples = linked_offset_samples
    result.source_start_seconds = (source_frames / effective_fps) + (linked_offset_samples / math.max(1, sample_rate))
    local linked_path_channel_index = math.max(1, tonumber(linked_local_channel_index) or 1)
    local linked_path_channel_count = 0
    for _, key in ipairs(linked_keys) do
        local candidate = linked_audio[key]
        if type(candidate) == "table" and candidate.path == linked_info.path then
            local candidate_channels = tonumber(candidate.channels) or 1
            linked_path_channel_count = linked_path_channel_count + candidate_channels
            if tonumber(key) < tonumber(linked_key) then
                linked_path_channel_index = linked_path_channel_index + candidate_channels
            end
        end
    end
    result.audio_channel_index = linked_path_channel_count > 1 and linked_path_channel_index or nil
    return result
end

local range_intersects_selection

function timeline_item_is_selected(item)
    local keys = {"Selected", "IsSelected", "selected", "isSelected"}
    for _, key in ipairs(keys) do
        local ok, value = pcall(function() return item:GetProperty(key) end)
        if ok and (value == true or tostring(value) == "1" or tostring(value):lower() == "true") then
            return true
        end
    end
    local ok_props, props = pcall(function() return item:GetProperty() end)
    if ok_props and type(props) == "table" then
        for _, key in ipairs(keys) do
            local value = props[key]
            if value == true or tostring(value) == "1" or tostring(value):lower() == "true" then
                return true
            end
        end
    end
    return false
end

local function get_audio_track_display_name(timeline, track_index)
    local ok_name, raw_name = pcall(function() return timeline:GetTrackName("audio", track_index) end)
    local name = ok_name and trim_text(raw_name) or ""
    if name == "" then
        return string.format("A%d", tonumber(track_index) or 0)
    end
    return string.format("A%d %s", tonumber(track_index) or 0, name)
end

local function compare_audio_source_priority(a, b)
    if a.is_selected ~= b.is_selected then return a.is_selected == true end
    local a_muted = a.audio_mapping_muted == true
    local b_muted = b.audio_mapping_muted == true
    if a_muted ~= b_muted then return a_muted == false end
    local a_overlap = tonumber(a.overlap_frames) or 0
    local b_overlap = tonumber(b.overlap_frames) or 0
    if a_overlap ~= b_overlap then return a_overlap > b_overlap end
    return (tonumber(a.item_index) or 0) < (tonumber(b.item_index) or 0)
end

local function collect_audio_sources_for_scope(timeline, scope, fps)
    if type(scope) ~= "table" or scope.mode ~= WORK_SCOPE_MODE_SELECTION then
        return nil, "无效的字幕生成范围"
    end
    local scope_start = tonumber(scope.start_frame)
    local scope_end = tonumber(scope.end_frame)
    if not scope_start or not scope_end or scope_end <= scope_start then
        return nil, "无效的字幕生成范围"
    end
    local ok_track_count, track_count = pcall(function() return timeline:GetTrackCount("audio") end)
    track_count = ok_track_count and tonumber(track_count) or 0
    if track_count <= 0 then
        return nil, "时间线没有音频轨"
    end

    local audio_sources = {}
    local effective_fps = math.max(1, tonumber(fps) or 30)
    for track_index = 1, track_count do
        local track_display_name = get_audio_track_display_name(timeline, track_index)
        local ok_items, items = pcall(function() return timeline:GetItemListInTrack("audio", track_index) end)
        items = ok_items and items or {}
        for item_index, item in ipairs(items or {}) do
            local ok_start, item_start = pcall(function() return item:GetStart() end)
            local ok_end, item_end = pcall(function() return item:GetEnd() end)
            item_start = ok_start and tonumber(item_start) or nil
            item_end = ok_end and tonumber(item_end) or nil
            if item_start and item_end and item_end > item_start then
                local overlap_start = math.max(scope_start, item_start)
                local overlap_end = math.min(scope_end, item_end)
                local overlap_frames = overlap_end - overlap_start
                if overlap_frames > 0 then
                    local file_path = get_audio_item_file_path(item)
                    if file_path then
                        local source_offset_frames, source_offset_fps = get_audio_item_source_offset_frames(item, effective_fps)
                        local ok_media, media_item = pcall(function() return item:GetMediaPoolItem() end)
                        media_item = ok_media and media_item or nil
                        local mapped_audio = parse_source_audio_channel_mapping(item, media_item, source_offset_fps, source_offset_frames, file_path)
                        file_path = mapped_audio.file_path or file_path
                        local item_source_start_seconds = tonumber(mapped_audio.source_start_seconds) or (source_offset_frames / source_offset_fps)
                        -- A linked recorder can start after the camera clip. Keep its first
                        -- available sample at the corresponding timeline frame.
                        if item_source_start_seconds < 0 then
                            local first_audio_frame = item_start + math.ceil(-item_source_start_seconds * effective_fps - 1e-8)
                            overlap_start = math.max(overlap_start, first_audio_frame)
                            overlap_frames = overlap_end - overlap_start
                        end
                        if overlap_frames > 0 then
                            local source_start_seconds = math.max(0, item_source_start_seconds + ((overlap_start - item_start) / effective_fps))
                            local source_end_seconds = source_start_seconds + (overlap_frames / effective_fps)
                            local candidate = {
                                file_path = file_path,
                                file_name = basename(file_path),
                                track_index = track_index,
                                track_name = track_display_name,
                                item_index = item_index,
                                item_start_frame = item_start,
                                item_end_frame = item_end,
                                start_frame = overlap_start,
                                end_frame = overlap_end,
                                source_offset_frames = source_offset_frames,
                                source_start_seconds = source_start_seconds,
                                source_end_seconds = source_end_seconds,
                                overlap_frames = overlap_frames
                            }
                            candidate.audio_mapping_source = mapped_audio.audio_mapping_source or "media_pool_file"
                            candidate.audio_mapping_fallback_reason = mapped_audio.audio_mapping_fallback_reason or ""
                            candidate.linked_offset_samples = mapped_audio.linked_offset_samples
                            candidate.audio_channel_index = mapped_audio.audio_channel_index
                            candidate.audio_mapping_muted = mapped_audio.audio_mapping_muted == true
                            candidate.is_selected = timeline_item_is_selected(item)
                            audio_sources[#audio_sources + 1] = candidate
                        end
                    end
                end
            end
        end
    end

    table.sort(audio_sources, function(a, b)
        local a_track = tonumber(a.track_index) or 0
        local b_track = tonumber(b.track_index) or 0
        if a_track ~= b_track then return a_track < b_track end
        return compare_audio_source_priority(a, b)
    end)

    if #audio_sources == 0 then
        return nil, "生成范围内没有可读取的本地音频片段"
    end
    return audio_sources
end

local function build_audio_track_options_for_dialog(audio_sources)
    if type(audio_sources) ~= "table" then
        return audio_sources
    end

    local sources_by_track = {}
    for _, source in ipairs(audio_sources) do
        local track_index = tonumber(source.track_index) or 0
        if not sources_by_track[track_index] then sources_by_track[track_index] = {} end
        sources_by_track[track_index][#sources_by_track[track_index] + 1] = source
    end

    local track_options = {}
    for _, grouped_sources in pairs(sources_by_track) do
        local usable_sources = {}
        for _, source in ipairs(grouped_sources) do
            if source.audio_mapping_muted ~= true then
                usable_sources[#usable_sources + 1] = source
            end
        end
        local sources = #usable_sources > 0 and usable_sources or grouped_sources
        table.sort(sources, function(a, b)
            local a_start = tonumber(a.start_frame) or 0
            local b_start = tonumber(b.start_frame) or 0
            if a_start ~= b_start then return a_start < b_start end
            local a_end = tonumber(a.end_frame) or 0
            local b_end = tonumber(b.end_frame) or 0
            if a_end ~= b_end then return a_end < b_end end
            return (tonumber(a.item_index) or 0) < (tonumber(b.item_index) or 0)
        end)

        local source = sources[1]
        local label = tostring(source.track_name or "")
        if label == "" then
            label = string.format("A%d", tonumber(source.track_index) or 0)
        end
        if #usable_sources == 0 and source.audio_mapping_muted == true then
            label = label .. "（静音）"
        end
        source.display_label = label
        source.track_sources = sources
        track_options[#track_options + 1] = source
    end

    table.sort(track_options, function(a, b)
        return (tonumber(a.track_index) or 0) < (tonumber(b.track_index) or 0)
    end)
    if #track_options > 0 then
        return track_options
    end
    return audio_sources
end

function range_intersects_selection(item_start, item_end, scope)
    local scope_start = tonumber(scope and scope.start_frame)
    local scope_end = tonumber(scope and scope.end_frame)
    if not scope_start or not scope_end then return false end
    local start_frame = tonumber(item_start)
    local end_frame = tonumber(item_end)
    if not start_frame or not end_frame then return false end
    return math.max(start_frame, end_frame) > scope_start and math.min(start_frame, end_frame) < scope_end
end

local get_subtitle_track_items

local function clear_subtitle_track_clips(timeline, track_index)
    local items, items_err = get_subtitle_track_items(track_index, timeline)
    if not items then return false, items_err end
    if #items == 0 then return true, 0 end
    local initial_count = #items
    local delete_ok = false
    local attempts = {
        function() return timeline:DeleteClips(items, false) end,
        function() return timeline:DeleteClips(items) end,
    }
    for _, delete_fn in ipairs(attempts) do
        local ok, ret = pcall(delete_fn)
        if ok and ret ~= false then
            delete_ok = true
            break
        end
    end
    if not delete_ok then
        return false, "清空目标字幕轨失败"
    end
    local remaining_items = select(1, get_subtitle_track_items(track_index, timeline)) or {}
    if #remaining_items > 0 then
        return false, "轨道 " .. tostring(track_index) .. " 仍残留 " .. tostring(#remaining_items) .. " 条字幕"
    end
    return true, initial_count
end

local function backup_target_track(timeline, track_index, fps, base_frame, progress_callback)
    local items, items_err = get_subtitle_track_items(track_index, timeline)
    if not items then return nil, items_err or "无法读取目标字幕轨", nil end
    if #items == 0 then return nil, nil, {} end

    local snapshot_rows = {}
    for item_position, item in ipairs(items) do
        local ok_start, start_frame = pcall(function() return item:GetStart() end)
        local ok_end, end_frame = pcall(function() return item:GetEnd() end)
        local ok_name, name = pcall(function() return item:GetName() end)
        if not ok_start or not ok_end then
            return nil, string.format("读取目标字幕轨第 %d 条失败，已停止写回", item_position), nil
        end
        snapshot_rows[#snapshot_rows + 1] = {
            start_frame = tonumber(start_frame) or 0,
            end_frame = tonumber(end_frame) or 0,
            text = tostring(ok_name and name or "")
        }

        local completed = item_position
        if progress_callback and (
            completed % GENERATE_BACKUP_PROGRESS_CHUNK_SIZE == 0 or completed == #items
        ) then
            if progress_callback(completed, #items) == false then
                return nil, "已取消", snapshot_rows, "cancelled"
            end
        end
    end

    local path = temp_dir() .. "/Backup_GenerateSelection_" .. os.date("%Y%m%d_%H%M%S") .. ".srt"
    local file = io.open(path, "w")
    if not file then return nil, "无法创建目标字幕轨备份", snapshot_rows end
    for index, row in ipairs(snapshot_rows) do
        file:write(tostring(index) .. "\n")
        file:write(frames_to_srt_time(row.start_frame, fps, base_frame) .. " --> " .. frames_to_srt_time(row.end_frame, fps, base_frame) .. "\n")
        file:write(tostring(row.text or "") .. "\n\n")
    end
    file:close()
    return path, nil, snapshot_rows
end

local function get_subtitle_track_type_and_count(timeline)
    if not timeline then return "subtitle", 0 end
    local candidates = {"subtitle", 3, "Subtitle"}
    for _, track_type in ipairs(candidates) do
        local ok, track_count = pcall(function() return timeline:GetTrackCount(track_type) end)
        if ok and track_count ~= nil and track_count ~= false then
            return track_type, tonumber(track_count) or 0
        end
    end
    return "subtitle", 0
end

function get_subtitle_track_items(track_index, timeline)
    if not track_index or track_index < 1 then
        return nil, "字幕轨索引无效"
    end
    local track_type, track_count = get_subtitle_track_type_and_count(timeline)
    if track_index > track_count then
        return nil, "轨道 " .. tostring(track_index) .. " 不存在", track_count, track_type
    end
    local tried = {}
    for _, candidate in ipairs({track_type, "subtitle", 3, "Subtitle"}) do
        local key = type(candidate) .. ":" .. tostring(candidate)
        if not tried[key] then
            tried[key] = true
            local ok_items, items = pcall(function() return timeline:GetItemListInTrack(candidate, track_index) end)
            if ok_items then
                return items or {}, nil, track_count, candidate
            end
        end
    end
    return nil, "无法读取轨道 " .. tostring(track_index) .. " 的字幕片段", track_count, track_type
end

local function add_subtitle_track(timeline)
    for _, track_type in ipairs({"subtitle", "Subtitle", 3}) do
        local ok, ret = pcall(function() return timeline:AddTrack(track_type) end)
        if ok and ret ~= false then return true end
    end
    return false
end

local function ensure_subtitle_track_exists(track_index, timeline)
    if not track_index or track_index < 1 then
        return nil, "字幕轨索引无效"
    end
    local _, track_count = get_subtitle_track_type_and_count(timeline)
    while track_count < track_index do
        local previous_count = track_count
        if not add_subtitle_track(timeline) then
            return nil, "无法创建字幕轨 " .. tostring(track_index)
        end
        _, track_count = get_subtitle_track_type_and_count(timeline)
        if track_count <= previous_count then
            return nil, "创建字幕轨后轨道数未变化"
        end
    end
    return get_subtitle_track_items(track_index, timeline)
end

local function unlock_all_subtitle_tracks(timeline)
    local track_type, track_count = get_subtitle_track_type_and_count(timeline)
    for track_index = 1, track_count do
        pcall(function() return timeline:SetTrackLock(track_type, track_index, false) end)
    end
    return true
end

local function isolate_subtitle_target_track(track_index, timeline)
    local track_type, track_count = get_subtitle_track_type_and_count(timeline)
    if track_index > track_count then
        return false, "目标字幕轨不存在"
    end
    for index = 1, track_count do
        local desired_enabled = index == track_index
        pcall(function() return timeline:SetTrackEnable(track_type, index, desired_enabled) end)
    end
    local ok_enabled, enabled = pcall(function() return timeline:GetIsTrackEnabled(track_type, track_index) end)
    if not ok_enabled or enabled == false then
        return false, "目标字幕轨未成功启用"
    end
    return true
end

local function format_audio_source_label(audio_source, fps)
    if audio_source.display_label and tostring(audio_source.display_label) ~= "" then
        return tostring(audio_source.display_label)
    end
    local overlap_seconds = (tonumber(audio_source.overlap_frames) or 0) / math.max(1, tonumber(fps) or 30)
    local marks = {}
    if audio_source.is_selected then marks[#marks + 1] = "选中" end
    if audio_source.audio_mapping_muted == true then marks[#marks + 1] = "mute" end
    if tostring(audio_source.audio_mapping_source or "") ~= "" then marks[#marks + 1] = tostring(audio_source.audio_mapping_source) end
    if tonumber(audio_source.audio_channel_index) then marks[#marks + 1] = "ch" .. tostring(math.floor(tonumber(audio_source.audio_channel_index) or 0)) end
    local prefix = #marks > 0 and ("[" .. table.concat(marks, "/") .. "] ") or ""
    return string.format(
        "%sA%d  #%d  %s  %.1fs  %.3f-%.3fs",
        prefix,
        tonumber(audio_source.track_index) or 0,
        tonumber(audio_source.item_index) or 0,
        tostring(audio_source.file_name or audio_source.file_path or ""),
        overlap_seconds,
        tonumber(audio_source.source_start_seconds) or 0,
        tonumber(audio_source.source_end_seconds) or 0
    )
end

local function write_selected_audio_source_diagnostic(path, audio_source, scope, source_optimization)
    if not path or not audio_source then return false end
    local selected_audio_sources = audio_source[1] and audio_source or {audio_source}
    local first_source = selected_audio_sources[1] or audio_source
    local sources = {}
    for _, selected_source in ipairs(selected_audio_sources) do
        for _, source in ipairs(selected_source.track_sources or {selected_source}) do
            sources[#sources + 1] = source
        end
    end
    local lines = {
        "{",
        '  "audio_source_mode": "source_audio",',
        string.format('  "track_index": %d,', tonumber(first_source.track_index) or 0),
        string.format('  "track_name": "%s",', json_escape(first_source.track_name or first_source.display_label)),
        '  "selected_tracks": ['
    }
    for index, selected_source in ipairs(selected_audio_sources) do
        lines[#lines + 1] = string.format(
            '    {"track_index": %d, "track_name": "%s", "source_count": %d}%s',
            tonumber(selected_source.track_index) or 0,
            json_escape(selected_source.track_name or selected_source.display_label),
            #(selected_source.track_sources or {selected_source}),
            index < #selected_audio_sources and "," or ""
        )
    end
    lines[#lines + 1] = "  ],"
    lines[#lines + 1] = string.format('  "source_count": %d,', #sources)
    local optimization = source_optimization or {}
    lines[#lines + 1] = '  "source_optimization": {'
    lines[#lines + 1] = string.format('    "raw_source_count": %d,', tonumber(optimization.raw_source_count) or #sources)
    lines[#lines + 1] = string.format('    "deduped_source_count": %d,', tonumber(optimization.deduped_source_count) or #sources)
    lines[#lines + 1] = string.format('    "merged_source_count": %d,', tonumber(optimization.merged_source_count) or #sources)
    lines[#lines + 1] = string.format('    "duplicate_source_count": %d,', tonumber(optimization.duplicate_source_count) or 0)
    lines[#lines + 1] = string.format('    "merged_source_group_count": %d,', tonumber(optimization.merged_source_group_count) or 0)
    lines[#lines + 1] = string.format('    "merged_child_source_count": %d', tonumber(optimization.merged_child_source_count) or 0)
    lines[#lines + 1] = "  },"
    lines[#lines + 1] =
        '  "sources": ['
    for index, source in ipairs(sources) do
        lines[#lines + 1] = "    {"
        lines[#lines + 1] = string.format('      "track_index": %d,', tonumber(source.track_index) or 0)
        lines[#lines + 1] = string.format('      "track_name": "%s",', json_escape(source.track_name or first_source.display_label))
        lines[#lines + 1] = string.format('      "item_index": %d,', tonumber(source.item_index) or 0)
        lines[#lines + 1] = string.format('      "file_path": "%s",', json_escape(source.file_path))
        lines[#lines + 1] = string.format('      "file_name": "%s",', json_escape(source.file_name))
        lines[#lines + 1] = string.format('      "audio_mapping_source": "%s",', json_escape(source.audio_mapping_source))
        lines[#lines + 1] = string.format('      "audio_mapping_fallback_reason": "%s",', json_escape(source.audio_mapping_fallback_reason))
        lines[#lines + 1] = string.format('      "audio_mapping_muted": %s,', source.audio_mapping_muted == true and "true" or "false")
        lines[#lines + 1] = string.format('      "audio_channel_index": %s,', tonumber(source.audio_channel_index) and tostring(math.floor(tonumber(source.audio_channel_index) or 0)) or "null")
        lines[#lines + 1] = string.format('      "linked_offset_samples": %s,', tonumber(source.linked_offset_samples) and tostring(tonumber(source.linked_offset_samples)) or "null")
        lines[#lines + 1] = string.format('      "source_offset_frames": %d,', tonumber(source.source_offset_frames) or 0)
        lines[#lines + 1] = string.format('      "source_start_seconds": %.6f,', tonumber(source.source_start_seconds) or 0)
        lines[#lines + 1] = string.format('      "source_end_seconds": %.6f,', tonumber(source.source_end_seconds) or 0)
        lines[#lines + 1] = string.format('      "timeline_start_frame": %d,', tonumber(source.start_frame) or 0)
        lines[#lines + 1] = string.format('      "timeline_end_frame": %d', tonumber(source.end_frame) or 0)
        lines[#lines + 1] = index < #sources and "    }," or "    }"
    end
    lines[#lines + 1] = "  ],"
    lines[#lines + 1] = string.format('  "selected_timeline_start_frame": %d,', tonumber(first_source.start_frame) or 0)
    lines[#lines + 1] = string.format('  "selected_timeline_end_frame": %d,', tonumber(first_source.end_frame) or 0)
    lines[#lines + 1] = string.format('  "timeline_start_frame": %d,', tonumber(scope and scope.timeline_start_frame) or 0)
    lines[#lines + 1] = string.format('  "scope_start_frame": %d,', tonumber(scope and scope.start_frame) or 0)
    lines[#lines + 1] = string.format('  "scope_end_frame": %d', tonumber(scope and scope.end_frame) or 0)
    lines[#lines + 1] = "}"
    return write_text_file(path, table.concat(lines, "\n") .. "\n")
end

local function collect_selected_track_sources(selected_audio_sources)
    local selected_track_sources = {}
    for track_order, audio_source in ipairs(selected_audio_sources or {}) do
        for _, source in ipairs(audio_source.track_sources or {audio_source}) do
            source.track_order = track_order
            source.source_order = #selected_track_sources + 1
            selected_track_sources[#selected_track_sources + 1] = source
        end
    end
    table.sort(selected_track_sources, function(a, b)
        local a_order = tonumber(a.track_order) or 0
        local b_order = tonumber(b.track_order) or 0
        if a_order ~= b_order then return a_order < b_order end
        local a_start = tonumber(a.start_frame) or 0
        local b_start = tonumber(b.start_frame) or 0
        if a_start ~= b_start then return a_start < b_start end
        return (tonumber(a.item_index) or 0) < (tonumber(b.item_index) or 0)
    end)
    return selected_track_sources
end

local function clone_audio_source(source)
    local cloned = {}
    for key, value in pairs(source or {}) do
        if key ~= "track_sources" then cloned[key] = value end
    end
    return cloned
end

local function rounded_number_key(value, precision)
    local multiplier = math.pow(10, tonumber(precision) or 3)
    return tostring(math.floor((tonumber(value) or 0) * multiplier + 0.5) / multiplier)
end

local function duplicate_audio_source_key(source)
    return table.concat({
        tostring(source and source.file_path or ""),
        rounded_number_key(source and source.source_start_seconds, 3),
        rounded_number_key(source and source.source_end_seconds, 3),
        tostring(math.floor(tonumber(source and source.start_frame) or 0)),
        tostring(math.floor(tonumber(source and source.audio_channel_index) or 0)),
    }, "|")
end

local function optimize_selected_track_sources_for_generation(selected_track_sources, fps)
    -- Only exact cross-track duplicates are removed here; keeping clip boundaries avoids long-window ASR drift.
    local stats = {
        raw_source_count = #(selected_track_sources or {}),
        deduped_source_count = 0,
        duplicate_source_count = 0,
        merged_source_count = 0,
        merged_source_group_count = 0,
        merged_child_source_count = 0
    }
    local deduped = {}
    local seen = {}
    for _, source in ipairs(selected_track_sources or {}) do
        local key = duplicate_audio_source_key(source)
        if seen[key] then
            stats.duplicate_source_count = stats.duplicate_source_count + 1
        else
            seen[key] = true
            deduped[#deduped + 1] = clone_audio_source(source)
        end
    end
    stats.deduped_source_count = #deduped
    table.sort(deduped, function(a, b)
        local a_order = tonumber(a.track_order) or 0
        local b_order = tonumber(b.track_order) or 0
        if a_order ~= b_order then return a_order < b_order end
        local a_start = tonumber(a.start_frame) or 0
        local b_start = tonumber(b.start_frame) or 0
        if a_start ~= b_start then return a_start < b_start end
        return (tonumber(a.item_index) or 0) < (tonumber(b.item_index) or 0)
    end)

    for _, source in ipairs(deduped) do
        source.merged_source_count = 1
        source.merged_item_indices = tostring(source.item_index or "")
    end
    stats.merged_source_count = #deduped
    return deduped, stats
end

-- Resolve can expose disabled camera angles and overlapping transition items.
-- Only a change on the uppermost enabled picture is a useful subtitle cut.
local function collect_generation_picture_cuts(timeline, scope)
    local events, frames, active, cuts = {}, {}, {}, {}
    local tracks = timeline:GetTrackCount("video") or 0
    local function add(frame, track, delta)
        if not events[frame] then
            events[frame] = {}
            frames[#frames + 1] = frame
        end
        events[frame][track] = (events[frame][track] or 0) + delta
    end
    for track = 1, tracks do
        if timeline:GetIsTrackEnabled("video", track) then
            for _, item in ipairs(timeline:GetItemListInTrack("video", track) or {}) do
                local first, last = item:GetStart(), item:GetEnd()
                if first and last and last > first and last > scope.start_frame and first < scope.end_frame
                        and item:GetClipEnabled() then
                    add(first, track, 1)
                    add(last, track, -1)
                end
            end
        end
    end
    table.sort(frames)
    local top = 0
    for _, frame in ipairs(frames) do
        local before, count = top, active[top]
        for track, delta in pairs(events[frame]) do
            active[track] = (active[track] or 0) + delta
        end
        top = tracks
        while top > 0 and (active[top] or 0) == 0 do top = top - 1 end
        if frame > scope.start_frame and frame < scope.end_frame and
                (before ~= top or (count == 1 and active[top] == 1 and events[frame][top] ~= nil)) then
            cuts[#cuts + 1] = frame
        end
    end
    return cuts
end

local function write_generate_batch_plan(path, selected_track_sources, fps, picture_cuts)
    local lines = {"{", '  "batches": ['}
    for index, source in ipairs(selected_track_sources or {}) do
        local audio_channel_index = tonumber(source.audio_channel_index)
        lines[#lines + 1] = "    {"
        local cuts = {}
        for _, frame in ipairs(picture_cuts or {}) do
            if frame >= source.start_frame and frame <= source.end_frame then
                cuts[#cuts + 1] = frame
            end
        end
        if #cuts > 0 then
            lines[#lines + 1] = '      "picture_cuts": [' .. table.concat(cuts, ",") .. '],'
        end
        lines[#lines + 1] = string.format('      "batch_id": "track%d_item%d_%d",', tonumber(source.track_index) or 0, tonumber(source.item_index) or 0, index)
        lines[#lines + 1] = string.format('      "audio": "%s",', json_escape(source.file_path))
        lines[#lines + 1] = string.format('      "source_start": %.6f,', tonumber(source.source_start_seconds) or 0)
        lines[#lines + 1] = string.format('      "source_end": %.6f,', tonumber(source.source_end_seconds) or 0)
        lines[#lines + 1] = string.format('      "timeline_start_frame": %d,', tonumber(source.start_frame) or 0)
        lines[#lines + 1] = string.format('      "timeline_end_frame": %d,', tonumber(source.end_frame) or 0)
        lines[#lines + 1] = string.format('      "fps": %.6f,', tonumber(fps) or 30)
        lines[#lines + 1] = string.format('      "audio_channel_index": %s,', audio_channel_index and tostring(math.floor(audio_channel_index)) or "null")
        lines[#lines + 1] = string.format('      "track_order": %d,', tonumber(source.track_order) or 0)
        lines[#lines + 1] = string.format('      "track_index": %d,', tonumber(source.track_index) or 0)
        lines[#lines + 1] = string.format('      "track_name": "%s",', json_escape(source.track_name or ""))
        lines[#lines + 1] = string.format('      "item_index": %d', tonumber(source.item_index) or 0)
        lines[#lines + 1] = index < #(selected_track_sources or {}) and "    }," or "    }"
    end
    lines[#lines + 1] = "  ]"
    lines[#lines + 1] = "}"
    return write_text_file(path, table.concat(lines, "\n") .. "\n")
end

local function parse_generated_json_subtitle_rows(json_path)
    local payload_text = read_text_file(json_path)
    if not payload_text then return nil, "无法读取生成 JSON" end
    local payload, decode_err = decode_json_text(payload_text)
    if not payload then return nil, decode_err or "生成 JSON 解析失败" end
    if payload.ok == false then return nil, tostring(payload.error or "ASR helper 执行失败") end
    local rows = {}
    for _, row in ipairs(payload.subtitle_rows or {}) do
        local start_frame = tonumber(row.start_frame)
        local end_frame = tonumber(row.end_frame)
        local text = trim_text(row.text or "")
        if start_frame and end_frame and end_frame > start_frame and text ~= "" then
            rows[#rows + 1] = {
                index = #rows + 1,
                start_frame = start_frame,
                end_frame = end_frame,
                text = text,
                batch_id = tostring(row.batch_id or ""),
                track_order = tonumber(row.track_order) or 0,
                track_index = tonumber(row.track_index) or 0,
                item_index = tonumber(row.item_index) or 0,
                speaker_track_index = tonumber(row.speaker_track_index),
                speaker_score_db = tonumber(row.speaker_score_db),
                speaker_decision = tostring(row.speaker_decision or "")
            }
        end
    end
    if #rows == 0 then return nil, "生成 JSON 没有可写回字幕" end
    return rows, nil, payload.generation_trace
end

local function subtract_existing_ranges(row, accepted_ranges)
    local intervals = {{start_frame = tonumber(row.start_frame) or 0, end_frame = tonumber(row.end_frame) or 0}}
    for _, range in ipairs(accepted_ranges or {}) do
        local next_intervals = {}
        local range_start = tonumber(range.start_frame) or 0
        local range_end = tonumber(range.end_frame) or 0
        for _, interval in ipairs(intervals) do
            local start_frame = tonumber(interval.start_frame) or 0
            local end_frame = tonumber(interval.end_frame) or 0
            if range_end <= start_frame or range_start >= end_frame then
                next_intervals[#next_intervals + 1] = interval
            else
                if range_start > start_frame then
                    next_intervals[#next_intervals + 1] = {start_frame = start_frame, end_frame = math.min(range_start, end_frame)}
                end
                if range_end < end_frame then
                    next_intervals[#next_intervals + 1] = {start_frame = math.max(range_end, start_frame), end_frame = end_frame}
                end
            end
        end
        intervals = next_intervals
        if #intervals == 0 then break end
    end
    return intervals
end

local function merge_generated_rows_with_track_priority(rows, scope)
    local sorted_rows = {}
    for _, row in ipairs(rows or {}) do sorted_rows[#sorted_rows + 1] = row end
    table.sort(sorted_rows, function(a, b)
        local a_order = tonumber(a.track_order) or tonumber(a.track_index) or 0
        local b_order = tonumber(b.track_order) or tonumber(b.track_index) or 0
        if a_order ~= b_order then return a_order < b_order end
        local a_start = tonumber(a.start_frame) or 0
        local b_start = tonumber(b.start_frame) or 0
        if a_start ~= b_start then return a_start < b_start end
        return (tonumber(a.end_frame) or 0) < (tonumber(b.end_frame) or 0)
    end)

    local accepted_ranges = {}
    local merged_rows = {}
    local scope_start = tonumber(scope and scope.start_frame)
    local scope_end = tonumber(scope and scope.end_frame)
    for _, row in ipairs(sorted_rows) do
        local row_start = tonumber(row.start_frame)
        local row_end = tonumber(row.end_frame)
        if row_start and row_end and row_end > row_start then
            if scope_start then row_start = math.max(row_start, scope_start) end
            if scope_end then row_end = math.min(row_end, scope_end) end
            if row_end > row_start then
                local candidate = {
                    start_frame = row_start,
                    end_frame = row_end,
                    text = row.text,
                    track_order = row.track_order,
                    track_index = row.track_index,
                    item_index = row.item_index
                }
                for _, interval in ipairs(subtract_existing_ranges(candidate, accepted_ranges)) do
                    if interval.end_frame > interval.start_frame then
                        local kept = {
                            start_frame = interval.start_frame,
                            end_frame = interval.end_frame,
                            text = candidate.text,
                            track_order = candidate.track_order,
                            track_index = candidate.track_index,
                            item_index = candidate.item_index
                        }
                        merged_rows[#merged_rows + 1] = kept
                        accepted_ranges[#accepted_ranges + 1] = {start_frame = kept.start_frame, end_frame = kept.end_frame}
                    end
                end
            end
        end
    end
    table.sort(merged_rows, function(a, b)
        local a_start = tonumber(a.start_frame) or 0
        local b_start = tonumber(b.start_frame) or 0
        if a_start ~= b_start then return a_start < b_start end
        return (tonumber(a.end_frame) or 0) < (tonumber(b.end_frame) or 0)
    end)
    for index, row in ipairs(merged_rows) do row.index = index end
    if #merged_rows == 0 then return nil, "按轨优先去重后没有可写回字幕" end
    return merged_rows
end

local function merge_generated_rows_for_live_writeback(rows, scope)
    for _, row in ipairs(rows or {}) do
        if not tonumber(row.speaker_track_index) then
            return merge_generated_rows_with_track_priority(rows, scope)
        end
    end

    local sorted_rows = {}
    local scope_start = tonumber(scope and scope.start_frame)
    local scope_end = tonumber(scope and scope.end_frame)
    for _, row in ipairs(rows or {}) do
        local start_frame = tonumber(row.start_frame)
        local end_frame = tonumber(row.end_frame)
        if start_frame and end_frame then
            if scope_start then start_frame = math.max(start_frame, scope_start) end
            if scope_end then end_frame = math.min(end_frame, scope_end) end
            if end_frame > start_frame then
                local candidate = {}
                for key, value in pairs(row) do candidate[key] = value end
                candidate.start_frame = start_frame
                candidate.end_frame = end_frame
                sorted_rows[#sorted_rows + 1] = candidate
            end
        end
    end
    table.sort(sorted_rows, function(a, b)
        local a_start = tonumber(a.start_frame) or 0
        local b_start = tonumber(b.start_frame) or 0
        if a_start ~= b_start then return a_start < b_start end
        local a_score = tonumber(a.speaker_score_db) or 0
        local b_score = tonumber(b.speaker_score_db) or 0
        if a_score ~= b_score then return a_score > b_score end
        return (tonumber(a.end_frame) or 0) < (tonumber(b.end_frame) or 0)
    end)

    local merged_rows = {}
    for _, row in ipairs(sorted_rows) do
        local previous = merged_rows[#merged_rows]
        if previous and tonumber(row.start_frame) < tonumber(previous.end_frame) then
            if tonumber(row.end_frame) <= tonumber(previous.end_frame) then
                if (tonumber(row.speaker_score_db) or 0) > (tonumber(previous.speaker_score_db) or 0) then
                    merged_rows[#merged_rows] = row
                end
                goto continue_live_row
            end
            previous.end_frame = math.max(tonumber(previous.start_frame) + 1, tonumber(row.start_frame))
            row.start_frame = tonumber(previous.end_frame)
        end
        if tonumber(row.end_frame) > tonumber(row.start_frame) then
            merged_rows[#merged_rows + 1] = row
        end
        ::continue_live_row::
    end
    for index, row in ipairs(merged_rows) do row.index = index end
    if #merged_rows == 0 then return nil, "现场模式没有可写回字幕" end
    return merged_rows
end

local function show_audio_track_selection_dialog(audio_sources, scope, fps)
    if not dispatcher or not ui then
        return nil, nil, nil, nil, nil, "无法初始化 Resolve UI"
    end
    if type(audio_sources) ~= "table" or #audio_sources == 0 then
        return nil, nil, nil, nil, nil, "生成范围内没有可读取的本地音频片段"
    end

    local selected_audio_sources = nil
    -- 模式选择下拉已移除，固定使用现场模式（单轨自然退化为单人识别）
    local subtitle_mode = "live"
    -- 字幕长度：标准（≤25字）/ 短视频（≤10字），默认标准。仅控制断句粒度
    -- （每条字幕最大字数），不涉及回声消除或断句算法本体。
    -- UI 用两个互斥的小勾选项代替下拉框/大按钮：与上方音频轨道列表同款的
    -- ☑/☐ 勾选样式，紧凑、一眼看出当前选中项。
    local SUBTITLE_LENGTH_OPTIONS = {
        {label = "标准（≤25字）", max_chars = 25},
        {label = "短视频（≤10字）", max_chars = 10},
    }
    local SUBTITLE_LENGTH_SELECTED_PREFIX = TRACK_CHECKED_MARK .. " "
    local SUBTITLE_LENGTH_UNSELECTED_PREFIX = TRACK_UNCHECKED_MARK .. " "
    local selected_length_index = 1
    local generate_preferences = runtime_options.model_center_draft or read_generate_preferences()
    for index, option in ipairs(SUBTITLE_LENGTH_OPTIONS) do
        if option.max_chars == tonumber(generate_preferences.max_chars) then
            selected_length_index = index
            break
        end
    end
    local selected_max_chars = SUBTITLE_LENGTH_OPTIONS[selected_length_index].max_chars
    -- 识别模型：主面板只保留 Qwen（本地）与豆包（云端）两个入口；豆包具体版本
    -- 在配置窗口内选择，并通过 selected_doubao_backend 映射到实际 helper backend。
    -- 仅决定把哪个 --backend 传给 ASR helper，不改断句/回声/对齐算法本体。默认
    -- Qwen(auto) 时与现状完全一致（build 传 DEFAULT_ASR_BACKEND == "auto"）。UI 复用
    -- 与字幕长度同款的 ☑/☐ 互斥小勾选样式。
    local SUBTITLE_ENGINE_OPTIONS = {
        {label = "Qwen（本地）", backend = "auto"},
        {label = "豆包（云端）", backend = "doubao"},
    }
    local SUBTITLE_ENGINE_SELECTED_PREFIX = TRACK_CHECKED_MARK .. " "
    local SUBTITLE_ENGINE_UNSELECTED_PREFIX = TRACK_UNCHECKED_MARK .. " "
    local selected_engine_index = 1
    local selected_doubao_backend = generate_preferences.doubao_backend or read_doubao_backend_preference()
    -- 记住上次选择的识别模型：命中偏好则默认选它（找不到/无偏好则保持默认 Qwen）。
    local last_engine_backend = generate_preferences.last_engine_backend or read_last_engine_backend()
    if last_engine_backend == "doubao_asr" or last_engine_backend == "doubao_asr_v2" then
        selected_engine_index = 2
    elseif last_engine_backend then
        for i, opt in ipairs(SUBTITLE_ENGINE_OPTIONS) do
            if opt.backend == last_engine_backend then
                selected_engine_index = i
                break
            end
        end
    end
    local selected_backend = SUBTITLE_ENGINE_OPTIONS[selected_engine_index].backend
    local hotword_entries = load_generate_hotword_entries()
    local hotwords_enabled = #hotword_entries > 0
    if type(generate_preferences.hotwords_enabled) == "boolean" then
        hotwords_enabled = hotwords_enabled and generate_preferences.hotwords_enabled
    end
    local selected_hotwords_json = nil
    local dialog_cancelled = false
    local qwen_install_requested = false
    local track_rows = {}
    local selection_window = dispatcher:AddWindow({
        ID = "GenerateSelectionWindow",
        WindowTitle = "SubFix · 生成选区字幕",
        Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({460, 250, 440, 348}),
    },
    ui:VGroup{
        Spacing = 8,
        ContentsMargins = {12, 12, 12, 18},
        ui:Label{ID = "GenerateSelectionInfoLabel", Text = "选择用于识别的音频轨道", Weight = 0},
        ui:Tree{
            ID = "GenerateAudioTrackTree",
            Weight = 1,
            MinimumSize = {0, 90},
            Events = {ItemClicked = true}
        },
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            ui:Label{Text = "字幕长度：", Weight = 0},
            ui:Button{ID = "GenerateSubtitleLengthStandardBtn", Text = "标准（≤25字）", Weight = 0, MinimumSize = {0, 20}},
            ui:Button{ID = "GenerateSubtitleLengthShortBtn", Text = "短视频（≤10字）", Weight = 0, MinimumSize = {0, 20}},
            ui:HGap(0, 1)
        },
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            ui:Label{Text = "识别模型：", Weight = 0},
            ui:Button{ID = "GenerateSubtitleEngineQwenBtn", Text = "Qwen（本地）", Weight = 0, MinimumSize = {0, 20}},
            ui:Button{ID = "GenerateSubtitleEngineDoubaoBtn", Text = "豆包（云端）", Weight = 0, MinimumSize = {0, 20}},
            ui:HGap(0, 1)
        },
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            ui:Label{Text = "热词库：", Weight = 0, MinimumSize = {64, 20}},
            ui:Button{ID = "GenerateHotwordToggleBtn", Text = "", Weight = 0, MinimumSize = {0, 20}},
            ui:Button{ID = "GenerateHotwordManageBtn", Text = "管理…", Weight = 0, MinimumSize = {0, 20}},
            ui:HGap(0, 1)
        },
        ui:HGroup{
            Weight = 0, Spacing = 8,
            ui:Label{Text = "参考文稿：", Weight = 0, MinimumSize = {64, 20}},
            ui:Button{ID = "GenerateReferenceToggleBtn", Text = "", Weight = 0, MinimumSize = {0, 20}},
            ui:Button{ID = "GenerateReferenceManageBtn", Text = "管理…", Weight = 0, MinimumSize = {0, 20}},
            ui:HGap(0, 1)
        },
        ui:Label{
            ID = "GenerateSelectionRangeLabel",
            Text = string.format(
                "%s：%d - %d%s",
                tostring(scope.source_label or "范围"),
                tonumber(scope.start_frame) or 0,
                tonumber(scope.end_frame) or 0,
                scope.item_name and scope.item_name ~= "" and (" · " .. tostring(scope.item_name)) or ""
            ),
            Weight = 0
        },
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            MinimumSize = {0, 36},
            ui:Button{ID = "GenerateSelectionConfirmBtn", Text = "生成", Weight = 1, MinimumSize = {0, 28}},
            ui:Button{ID = "GenerateSelectionCancelBtn", Text = "取消", Weight = 1, MinimumSize = {0, 28}}
        },
        ui:VGap(8, 0)
    })

    local items = selection_window:GetItems()
    local project_path = runtime_options.project_reference_path
    local saved_reference = read_generate_reference(project_path)
    local previous_reference, previous_label
    if not saved_reference then
        previous_reference = read_generate_reference(resolve_asr_paths().reference_base .. ".json")
        previous_label = "载入旧版文稿"
        if (not previous_reference or previous_reference.text == "") and trim_text(runtime_options.correction_reference) ~= "" then
            previous_reference = {text = runtime_options.correction_reference, enabled = true}
            previous_label = "载入矫正文稿"
        end
        saved_reference = {text = "", enabled = false}
    end
    local reference_text, reference_enabled = saved_reference.text, saved_reference.enabled
    if runtime_options.model_center_draft then
        reference_text = runtime_options.reference_text or ""
        reference_enabled = runtime_options.reference_enabled == true
    end
    local reference_hint = project_path and "粘贴文稿或关键词，最多 10000 字。" or "未取得项目 ID，参考文稿仅用于本次生成。"
    local reference_window = dispatcher:AddWindow({
        ID = "GenerateReferenceWindow", WindowTitle = "SubFix · 管理参考文稿",
        Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({475, 250, 460, 280})
    }, ui:VGroup{
        ContentsMargins = 12, Spacing = 8,
        ui:Label{ID = "GenerateReferenceStatus", Text = reference_hint, Weight = 0},
        ui:TextEdit{ID = "GenerateReferenceText", PlainText = reference_text, AcceptRichText = false,
            Weight = 1, MinimumSize = {0, 100}, Events = {TextChanged = true},
            PlaceholderText = "输入文稿、人名或术语，或导入 TXT、Markdown、Word（.docx）"},
        ui:HGroup{Weight = 0, Spacing = 8,
            ui:Button{ID = "GenerateReferenceImport", Text = "导入文档…", Weight = 0},
            ui:Button{ID = "GenerateReferencePrevious", Text = previous_label or "", Visible = previous_reference ~= nil and previous_reference.text ~= "", Weight = 0},
            ui:Button{ID = "GenerateReferenceClear", Text = "清空", Weight = 0},
            ui:HGap(0, 1),
            ui:Button{ID = "GenerateReferenceDone", Text = "完成", Weight = 0}
        }
    })
    local reference_items = reference_window:GetItems()
    local reference_input = reference_items.GenerateReferenceText
    local reference_status = reference_items.GenerateReferenceStatus
    local function refresh_reference()
        local text = trim_text(reference_input.PlainText or "")
        if text == "" or reference_text == "" then reference_enabled = text ~= "" end
        reference_text = text
        local _, count = text:gsub("[^\128-\191]", "")
        local mark = reference_enabled and TRACK_CHECKED_MARK or TRACK_UNCHECKED_MARK
        items.GenerateReferenceToggleBtn.Text = mark .. " " .. count .. " 字"
        return count
    end
    local function reference_fits()
        if refresh_reference() <= 10000 or not reference_enabled then return true end
        reference_status.Text = "参考文稿超过 10000 字，请精简后再生成"
        reference_window:Show()
        return false
    end
    local function remember_reference(show_error)
        refresh_reference()
        if saved_reference and saved_reference.text == reference_text and saved_reference.enabled == reference_enabled then
            return true
        end
        if not project_path then return true end
        if not write_generate_reference(project_path, reference_text, reference_enabled) then
            local message = "参考文稿保存失败，请检查插件支持目录的写入权限后重试"
            reference_status.Text = message
            if show_error then reference_window:Show() else print("[SubFix Generate] " .. message) end
            return false
        end
        saved_reference = {text = reference_text, enabled = reference_enabled}
        return true
    end
    function reference_window.On.GenerateReferenceText.TextChanged(ev)
        refresh_reference()
    end
    function reference_window.On.GenerateReferencePrevious.Clicked(ev)
        if not previous_reference then return end
        reference_input.PlainText = previous_reference.text
        refresh_reference()
        reference_enabled = previous_reference.enabled
        refresh_reference()
    end
    function reference_window.On.GenerateReferenceClear.Clicked(ev)
        reference_input.PlainText = ""
        saved_reference = nil
        if remember_reference(true) then reference_status.Text = reference_hint end
    end
    function reference_window.On.GenerateReferenceImport.Clicked(ev)
        local ok, path = pcall(function() return fusion_app:RequestFile("") end)
        if not ok then reference_status.Text = "无法打开文件选择器，可直接粘贴文稿"; return end
        if not path or path == "" then return end
        local ext = path:lower():match("%.([^.]+)$")
        if ext ~= "txt" and ext ~= "md" and ext ~= "docx" then
            reference_status.Text = "请选择 TXT、Markdown 或 Word（.docx）文档"
            return
        end
        local format = ext == "docx" and "docx" or "txt"
        local pipe = io.popen("/usr/bin/textutil -convert txt -stdout -encoding UTF-8 -format "
            .. format .. " " .. shell_quote(path) .. " 2>/dev/null", "r")
        local text = pipe and pipe:read(40004)
        if pipe then pipe:close() end
        if text and #text == 40004 then
            reference_status.Text = "参考文稿超过 10000 字，请精简后再导入"
            return
        end
        text = trim_text((text or ""):gsub("^\239\187\191", ""))
        if text == "" then reference_status.Text = "文档没有可读取的文字，可直接粘贴文稿"; return end
        local _, count = text:gsub("[^\128-\191]", "")
        if count > 10000 then reference_status.Text = "参考文稿超过 10000 字，请精简后再导入"; return end
        reference_input.PlainText = text
        refresh_reference()
        reference_status.Text = "已导入参考文稿，可在下方编辑"
    end
    function reference_window.On.GenerateReferenceDone.Clicked(ev)
        if reference_fits() and remember_reference(true) then reference_window:Hide() end
    end
    function reference_window.On.GenerateReferenceWindow.Close(ev)
        if reference_fits() and remember_reference(true) then reference_window:Hide() end
    end
    function selection_window.On.GenerateReferenceManageBtn.Clicked(ev)
        reference_window:Show()
    end
    function selection_window.On.GenerateReferenceToggleBtn.Clicked(ev)
        if refresh_reference() == 0 then reference_window:Show(); return end
        reference_enabled = not reference_enabled
        remember_reference(true)
    end
    refresh_reference()
    local track_tree = items and items.GenerateAudioTrackTree or nil
    if not track_tree then return nil, nil, nil, nil, "无法初始化音频轨道列表" end
    pcall(function() track_tree.ColumnCount = 2 end)
    pcall(function() track_tree.HeaderHidden = true end)
    pcall(function() track_tree.RootIsDecorated = false end)
    pcall(function() track_tree.ItemsExpandable = false end)
    pcall(function() track_tree.ColumnWidth[0] = 28 end)
    pcall(function() track_tree.ColumnWidth[1] = 340 end)

    local length_standard_btn = items and items.GenerateSubtitleLengthStandardBtn or nil
    local length_short_btn = items and items.GenerateSubtitleLengthShortBtn or nil

    local function refresh_subtitle_length_buttons()
        if length_standard_btn then
            local prefix = selected_length_index == 1 and SUBTITLE_LENGTH_SELECTED_PREFIX or SUBTITLE_LENGTH_UNSELECTED_PREFIX
            pcall(function() length_standard_btn.Text = prefix .. SUBTITLE_LENGTH_OPTIONS[1].label end)
        end
        if length_short_btn then
            local prefix = selected_length_index == 2 and SUBTITLE_LENGTH_SELECTED_PREFIX or SUBTITLE_LENGTH_UNSELECTED_PREFIX
            pcall(function() length_short_btn.Text = prefix .. SUBTITLE_LENGTH_OPTIONS[2].label end)
        end
    end

    local function select_subtitle_length(index)
        selected_length_index = index
        refresh_subtitle_length_buttons()
    end

    refresh_subtitle_length_buttons()

    local function read_selected_max_chars()
        local option = SUBTITLE_LENGTH_OPTIONS[selected_length_index]
        return option and option.max_chars or SUBTITLE_LENGTH_OPTIONS[1].max_chars
    end

    local engine_qwen_btn = items and items.GenerateSubtitleEngineQwenBtn or nil
    local engine_doubao_btn = items and items.GenerateSubtitleEngineDoubaoBtn or nil
    local hotword_toggle_btn = items and items.GenerateHotwordToggleBtn or nil

    local function refresh_subtitle_engine_buttons()
        if engine_qwen_btn then
            local prefix = selected_engine_index == 1 and SUBTITLE_ENGINE_SELECTED_PREFIX or SUBTITLE_ENGINE_UNSELECTED_PREFIX
            pcall(function() engine_qwen_btn.Text = prefix .. SUBTITLE_ENGINE_OPTIONS[1].label end)
        end
        if engine_doubao_btn then
            local prefix = selected_engine_index == 2 and SUBTITLE_ENGINE_SELECTED_PREFIX or SUBTITLE_ENGINE_UNSELECTED_PREFIX
            pcall(function() engine_doubao_btn.Text = prefix .. SUBTITLE_ENGINE_OPTIONS[2].label end)
        end
    end

    local function select_subtitle_engine(index)
        selected_engine_index = index
        refresh_subtitle_engine_buttons()
    end

    refresh_subtitle_engine_buttons()

    local function read_selected_backend()
        if selected_engine_index == 2 then
            return selected_doubao_backend
        end
        return "auto"
    end

    local hotword_library_window = nil
    local hotword_clear_confirm_window = nil
    local hotword_library_closing = false
    local function refresh_hotword_toggle()
        if not hotword_toggle_btn then return end
        local prefix = hotwords_enabled and TRACK_CHECKED_MARK or TRACK_UNCHECKED_MARK
        local count_text = tostring(#hotword_entries) .. " 条"
        if #hotword_entries > 200 then count_text = count_text .. "（本次前200条）" end
        pcall(function() hotword_toggle_btn.Text = prefix .. " " .. count_text end)
    end

    local function show_hotword_library_dialog()
        if hotword_library_window then
            hotword_library_closing = false
            pcall(function() hotword_library_window:Show() end)
            return
        end
        hotword_library_window = dispatcher:AddWindow({
            ID = "GenerateHotwordLibraryWindow",
            WindowTitle = "SubFix · 热词库",
            Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({620, 330, 520, 290}),
        },
        ui:VGroup{
            Spacing = 6,
            ContentsMargins = 10,
            ui:Tree{ID = "GenerateHotwordTree", Weight = 1, MinimumSize = {0, 90}, Events = {ItemClicked = true}},
            ui:HGroup{
                Weight = 0, Spacing = 8,
                ui:Label{Text = "标准词：", Weight = 0},
                ui:LineEdit{ID = "GenerateHotwordTermInput", PlaceholderText = "例如 DaVinci Resolve", Weight = 1, Events = {ReturnPressed = true}}
            },
            ui:HGroup{
                Weight = 0, Spacing = 8,
                MinimumSize = {0, 34},
                ui:Button{ID = "GenerateHotwordAddBtn", Text = "新增", Weight = 1, MinimumSize = {0, 28}},
                ui:Button{ID = "GenerateHotwordDeleteBtn", Text = "删除", Weight = 1, MinimumSize = {0, 28}},
                ui:Button{ID = "GenerateHotwordClearBtn", Text = "清空", Weight = 1, MinimumSize = {0, 28}}
            },
            ui:VGap(10),
            ui:HGroup{
                Weight = 0, Spacing = 8,
                MinimumSize = {0, 34},
                ui:Button{ID = "GenerateHotwordCloseBtn", Text = "完成", Weight = 1, MinimumSize = {0, 28}}
            },
            ui:Label{ID = "GenerateHotwordStatusLabel", Text = "", Weight = 0}
        })
        local library_items = hotword_library_window:GetItems()
        local hotword_tree = library_items and library_items.GenerateHotwordTree or nil
        local term_input = library_items and library_items.GenerateHotwordTermInput or nil
        local status_label = library_items and library_items.GenerateHotwordStatusLabel or nil
        local item_map, selected_hotword_index = {}, nil
        local hotword_library_dirty = false
        if hotword_tree then
            pcall(function() hotword_tree.ColumnCount = 1 end)
            pcall(function() hotword_tree.HeaderHidden = true end)
        end

        local function set_hotword_status(text)
            if status_label then pcall(function() status_label.Text = tostring(text or "") end) end
        end
        local function refresh_hotword_tree()
            item_map = {}
            if hotword_tree then pcall(function() hotword_tree:Clear() end) end
            for index, entry in ipairs(hotword_entries) do
                local ok_item, item = pcall(function() return hotword_tree:NewItem() end)
                if ok_item and item then
                    set_tree_item_text(item, 0, tostring(entry.term))
                    pcall(function() hotword_tree:AddTopLevelItem(item) end)
                    item_map[item] = index
                end
            end
            safe_refresh_tree_widget(hotword_tree)
            refresh_hotword_toggle()
        end
        local function append_hotword_tree_entry(index, entry)
            if not hotword_tree or not entry then return end
            local ok_item, item = pcall(function() return hotword_tree:NewItem() end)
            if not ok_item or not item then return end
            set_tree_item_text(item, 0, tostring(entry.term))
            pcall(function() hotword_tree:AddTopLevelItem(item) end)
            item_map[item] = index
            safe_refresh_tree_widget(hotword_tree)
        end
        local function save_hotword_library()
            if not hotword_library_dirty then return true end
            if not save_generate_hotword_entries(hotword_entries) then
                set_hotword_status("保存失败，请检查本机插件支持目录权限")
                return false
            end
            hotword_library_dirty = false
            return true
        end
        function hotword_library_window.On.GenerateHotwordTree.ItemClicked(ev)
            local item = get_tree_event_value(ev, {"item", "Item", "currentItem", "CurrentItem"}) or get_selected_tree_node(hotword_tree)
            selected_hotword_index = item and item_map[item] or nil
        end
        local function add_hotword()
            local term = trim_text(term_input and term_input.Text or "")
            if term == "" then set_hotword_status("请填写标准词") return end
            hotword_entries[#hotword_entries + 1] = {term = term, aliases = {}}
            selected_hotword_index = #hotword_entries
            hotword_library_dirty = true
            hotwords_enabled = #hotword_entries > 0
            append_hotword_tree_entry(selected_hotword_index, hotword_entries[selected_hotword_index])
            if term_input then pcall(function() term_input.Text = "" end) end
            refresh_hotword_toggle()
            set_hotword_status("已添加，点击完成保存")
        end
        function hotword_library_window.On.GenerateHotwordAddBtn.Clicked(ev)
            add_hotword()
        end
        function hotword_library_window.On.GenerateHotwordTermInput.ReturnPressed(ev)
            add_hotword()
        end
        function hotword_library_window.On.GenerateHotwordDeleteBtn.Clicked(ev)
            if not selected_hotword_index then set_hotword_status("请先选择要删除的词条") return end
            table.remove(hotword_entries, selected_hotword_index)
            selected_hotword_index = nil
            if term_input then pcall(function() term_input.Text = "" end) end
            hotword_library_dirty = true
            hotwords_enabled = #hotword_entries > 0
            refresh_hotword_tree()
            set_hotword_status("已删除，点击完成保存")
        end
        local function hide_hotword_clear_confirmation()
            if hotword_clear_confirm_window then
                pcall(function() hotword_clear_confirm_window:Hide() end)
            end
        end
        local function show_hotword_clear_confirmation()
            if #hotword_entries == 0 then
                set_hotword_status("当前没有热词可清空")
                return
            end
            if not hotword_clear_confirm_window then
                hotword_clear_confirm_window = dispatcher:AddWindow({
                    ID = "GenerateHotwordClearConfirmWindow",
                    WindowTitle = "SubFix · 清空热词库",
                    Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({720, 390, 360, 80}),
                },
                ui:VGroup{
                    Spacing = 10,
                    ContentsMargins = 14,
                    ui:Label{Text = "确定清空全部热词吗？此操作无法撤销。", WordWrap = true, Weight = 0},
                    ui:HGroup{
                        Weight = 0, Spacing = 8,
                        MinimumSize = {0, 34},
                        ui:Button{ID = "GenerateHotwordClearCancelBtn", Text = "取消", Weight = 1, MinimumSize = {0, 28}},
                        ui:Button{ID = "GenerateHotwordClearConfirmBtn", Text = "清空全部", Weight = 1, MinimumSize = {0, 28}}
                    },
                    ui:VGap(8, 0)
                })
                function hotword_clear_confirm_window.On.GenerateHotwordClearCancelBtn.Clicked(ev)
                    hide_hotword_clear_confirmation()
                end
                function hotword_clear_confirm_window.On.GenerateHotwordClearConfirmBtn.Clicked(ev)
                    hotword_entries = {}
                    selected_hotword_index = nil
                    if term_input then pcall(function() term_input.Text = "" end) end
                    hotword_library_dirty = true
                    hotwords_enabled = false
                    refresh_hotword_tree()
                    set_hotword_status("已清空，点击完成保存")
                    hide_hotword_clear_confirmation()
                end
                function hotword_clear_confirm_window.On.GenerateHotwordClearConfirmWindow.Close(ev)
                    hide_hotword_clear_confirmation()
                end
            end
            pcall(function() hotword_clear_confirm_window:Show() end)
        end
        function hotword_library_window.On.GenerateHotwordClearBtn.Clicked(ev)
            show_hotword_clear_confirmation()
        end
        local function close_hotword_library()
            if hotword_library_closing then return end
            hotword_library_closing = true
            hide_hotword_clear_confirmation()
            if not save_hotword_library() then
                hotword_library_closing = false
                return
            end
            pcall(function() hotword_library_window:Hide() end)
        end
        function hotword_library_window.On.GenerateHotwordCloseBtn.Clicked(ev)
            close_hotword_library()
        end
        function hotword_library_window.On.GenerateHotwordLibraryWindow.Close(ev)
            close_hotword_library()
        end
        refresh_hotword_tree()
        pcall(function() hotword_library_window:Show() end)
    end

    function selection_window.On.GenerateHotwordToggleBtn.Clicked(ev)
        if #hotword_entries == 0 then
            show_hotword_library_dialog()
            return
        end
        hotwords_enabled = not hotwords_enabled
        refresh_hotword_toggle()
    end
    function selection_window.On.GenerateHotwordManageBtn.Clicked(ev)
        show_hotword_library_dialog()
    end
    refresh_hotword_toggle()

    -- 豆包密钥配置子窗口：点"豆包（云端）"且未配置密钥时按需弹出。复用父对话框
    -- 已在跑的 dispatcher:RunLoop() 作非模态覆盖，子窗口自身不 RunLoop/ExitLoop，
    -- 避免嵌套事件循环。
    local DOUBAO_API_KEY_GUIDE_URL = "https://console.volcengine.com/speech/new/setting/apikeys"
    local doubao_key_window = dispatcher:AddWindow({
        ID = "GenerateDoubaoKeyWindow",
        WindowTitle = "SubFix · 配置豆包 API Key",
        Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({500, 300, 420, 228}),
        MinimumSize = {420, 228},
    },
    ui:VGroup{
        Spacing = 8,
        ContentsMargins = 12,
        ui:Label{Text = "填写火山引擎（豆包）语音识别 API Key", Weight = 0},
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            ui:Label{Text = "API Key：", Weight = 0, MinimumSize = {96, 0}},
            ui:LineEdit{ID = "GenerateDoubaoApiKeyInput", PlaceholderText = "火山引擎 API Key", Weight = 1}
        },
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            MinimumSize = {0, 36},
            ui:Label{Text = "识别版本：", Weight = 0, MinimumSize = {96, 0}},
            ui:ComboBox{ID = "GenerateDoubaoBackendSelector", Weight = 1, MinimumSize = {0, 32}}
        },
        ui:VGap(8),
        ui:VGroup{
            Weight = 0,
            Spacing = 0,
            ui:HGroup{
                Weight = 0,
                MinimumSize = {0, 28},
                ui:Button{
                    ID = "GenerateDoubaoApiKeyGuideBtn",
                    Text = "获取豆包语音 API Key ↗",
                    Weight = 1,
                    MinimumSize = {0, 28},
                },
            },
            ui:VGap(12),
            ui:Label{ID = "GenerateDoubaoKeyStatusLabel", Text = "密钥仅保存在本机，不会上传或进入版本库。", Weight = 0, MinimumSize = {0, 18}},
            ui:VGap(4),
        },
        ui:HGroup{
            Weight = 0,
            MinimumSize = {0, 36},
            Spacing = 8,
            ui:Button{ID = "GenerateDoubaoKeySaveBtn", Text = "保存", Weight = 1, MinimumSize = {0, 36}},
            ui:Button{ID = "GenerateDoubaoKeyCancelBtn", Text = "取消", Weight = 1, MinimumSize = {0, 36}}
        }
    })

    local doubao_key_items = doubao_key_window:GetItems()
    local doubao_api_key_input = doubao_key_items and doubao_key_items.GenerateDoubaoApiKeyInput or nil
    local doubao_backend_selector = doubao_key_items and doubao_key_items.GenerateDoubaoBackendSelector or nil
    local doubao_key_status_label = doubao_key_items and doubao_key_items.GenerateDoubaoKeyStatusLabel or nil
    local pending_doubao_backend = selected_doubao_backend
    if doubao_backend_selector then
        doubao_backend_selector:AddItem("极速版")
        doubao_backend_selector:AddItem("2.0 标准版")
    end

    local function set_doubao_key_status(text)
        if doubao_key_status_label then
            pcall(function() doubao_key_status_label.Text = tostring(text or "") end)
        end
    end

    local function open_doubao_api_key_guide()
        local ok, result = pcall(
            os.execute,
            "/usr/bin/open " .. shell_quote(DOUBAO_API_KEY_GUIDE_URL) .. " >/dev/null 2>&1"
        )
        if not ok or (result ~= true and result ~= 0) then
            set_doubao_key_status("无法打开浏览器，请手动访问火山引擎豆包语音控制台")
        end
    end

    function doubao_key_window.On.GenerateDoubaoApiKeyGuideBtn.Clicked(ev)
        open_doubao_api_key_guide()
    end

    local function refresh_doubao_backend_selector()
        if not doubao_backend_selector then return end
        local backend_index = pending_doubao_backend == "doubao_asr_v2" and 1 or 0
        pcall(function() doubao_backend_selector.CurrentIndex = backend_index end)
    end

    -- 弹出前用已存值预填，方便查看/修改；再 Show（非模态覆盖，父 RunLoop 继续分发事件）。
    local function open_doubao_key_dialog()
        local api_key = read_doubao_api_key()
        if doubao_api_key_input then pcall(function() doubao_api_key_input.Text = api_key end) end
        pending_doubao_backend = selected_doubao_backend
        refresh_doubao_backend_selector()
        set_doubao_key_status("密钥仅保存在本机，不会上传或进入版本库。")
        pcall(function() doubao_key_window:Show() end)
    end

    function doubao_key_window.On.GenerateDoubaoBackendSelector.CurrentIndexChanged(ev)
        if not doubao_backend_selector then return end
        local backend_index = tonumber(doubao_backend_selector.CurrentIndex) or 0
        pending_doubao_backend = backend_index == 1 and "doubao_asr_v2" or "doubao_asr"
    end

    function doubao_key_window.On.GenerateDoubaoKeySaveBtn.Clicked(ev)
        local api_key = trim_text(doubao_api_key_input and doubao_api_key_input.Text or "")
        if api_key == "" then
            set_doubao_key_status("请输入 API Key")
            return
        end
        local previous_api_key = read_doubao_api_key()
        local previous_doubao_backend = selected_doubao_backend
        local ok, err = save_doubao_api_key(api_key)
        if not ok then
            set_doubao_key_status(tostring(err or "保存失败"))
            return
        end
        selected_doubao_backend = normalize_doubao_backend(pending_doubao_backend)
        local pref_ok, pref_err = save_doubao_backend_preference(selected_doubao_backend)
        if not pref_ok then
            local rollback_ok, rollback_err = save_doubao_api_key(previous_api_key)
            selected_doubao_backend = previous_doubao_backend
            local preference_error = tostring(pref_err or "模型偏好保存失败，请检查本机插件支持目录权限")
            if not rollback_ok then
                set_doubao_key_status(
                    preference_error .. "；API Key 回滚失败：" .. tostring(rollback_err or "未知错误")
                )
            else
                set_doubao_key_status(preference_error)
            end
            return
        end
        pcall(function() doubao_key_window:Hide() end)
    end

    -- 取消/关闭：已配置时只丢弃本次草稿；未配置时切回 Qwen，避免生成时静默回退。
    local function cancel_doubao_key_dialog()
        pcall(function() doubao_key_window:Hide() end)
        if not doubao_credentials_configured() then
            select_subtitle_engine(1)
            if items and items.GenerateSelectionInfoLabel then
                items.GenerateSelectionInfoLabel.Text = "未配置豆包密钥，已切回 Qwen（本地）"
            end
        end
    end

    function doubao_key_window.On.GenerateDoubaoKeyCancelBtn.Clicked(ev)
        cancel_doubao_key_dialog()
    end

    function doubao_key_window.On.GenerateDoubaoKeyWindow.Close(ev)
        cancel_doubao_key_dialog()
    end

    -- 未配置提醒子窗口：单击豆包且未配置时首次提示（引导双击去配置）。同样复用父
    -- RunLoop 作非模态覆盖；"知道了"仅关闭提示、保持豆包选中，等用户双击配置。
    local doubao_reminder_window = dispatcher:AddWindow({
        ID = "GenerateDoubaoReminderWindow",
        WindowTitle = "SubFix · 豆包密钥未配置",
        Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({520, 320, 380, 150}),
    },
    ui:VGroup{
        Spacing = 8,
        ContentsMargins = 12,
        ui:Label{Text = "已选择「豆包（云端）」，但尚未配置密钥。", Weight = 0},
        ui:Label{Text = "请双击「豆包（云端）」按钮填写 API Key。", Weight = 0},
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            ui:HGap(0, 1),
            ui:Button{ID = "GenerateDoubaoReminderOkBtn", Text = "知道了", Weight = 0, MinimumSize = {88, 28}}
        }
    })

    function doubao_reminder_window.On.GenerateDoubaoReminderOkBtn.Clicked(ev)
        pcall(function() doubao_reminder_window:Hide() end)
    end

    function doubao_reminder_window.On.GenerateDoubaoReminderWindow.Close(ev)
        pcall(function() doubao_reminder_window:Hide() end)
    end

    local qwen_download_window = dispatcher:AddWindow({
        ID = "GenerateQwenDownloadWindow",
        WindowTitle = "SubFix · 模型准备",
        Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({560, 330, 480, 180}),
    },
    ui:VGroup{
        Spacing = 8,
        ContentsMargins = 14,
        ui:Label{ID = "GenerateQwenDownloadStatusLabel", Text = "请在模型中心准备需要的模型。", WordWrap = true, Weight = 0},
        ui:Label{ID = "GenerateQwenDownloadDetailLabel", Text = "本地识别需要 ASR 和对齐模型；豆包使用云端时间戳，无需本地模型。", WordWrap = true, Weight = 0},
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            MinimumSize = {0, 34},
            ui:Button{ID = "GenerateQwenDownloadConfirmBtn", Text = "打开模型中心", Weight = 1, MinimumSize = {0, 28}},
            ui:Button{ID = "GenerateQwenDownloadCancelBtn", Text = "取消", Weight = 1, MinimumSize = {0, 28}}
        }
    })

    local qwen_download_items = qwen_download_window:GetItems()
    local qwen_download_status_label = qwen_download_items and qwen_download_items.GenerateQwenDownloadStatusLabel or nil
    local qwen_download_detail_label = qwen_download_items and qwen_download_items.GenerateQwenDownloadDetailLabel or nil
    local qwen_download_confirm_btn = qwen_download_items and qwen_download_items.GenerateQwenDownloadConfirmBtn or nil
    local qwen_download_is_ready = false

    local function show_qwen_status(qwen_status)
        qwen_download_is_ready = qwen_status and qwen_status.ready == true
        if qwen_download_is_ready then
            if qwen_download_status_label then qwen_download_status_label.Text = "选中的本地模型与对齐模型已就绪。" end
            if qwen_download_detail_label then qwen_download_detail_label.Text = "可在模型中心切换识别模型或导入已有模型。" end
            if qwen_download_confirm_btn then
                qwen_download_confirm_btn.Text = "打开模型中心"
                qwen_download_confirm_btn.Enabled = true
            end
        else
            if qwen_download_status_label then qwen_download_status_label.Text = "当前功能需要的模型或运行环境尚未就绪。" end
            if qwen_download_detail_label then qwen_download_detail_label.Text = "请在模型中心下载或导入本地模型。豆包生成字幕无需本地模型。" end
            if qwen_download_confirm_btn then
                qwen_download_confirm_btn.Text = "打开模型中心"
                qwen_download_confirm_btn.Enabled = true
            end
        end
    end

    local function open_qwen_download_dialog()
        qwen_download_is_ready = false
        if qwen_download_status_label then qwen_download_status_label.Text = "正在检查本地 Qwen 安装状态…" end
        if qwen_download_detail_label then qwen_download_detail_label.Text = "请稍候，窗口会自动更新。" end
        if qwen_download_confirm_btn then
            qwen_download_confirm_btn.Text = "检查中…"
            qwen_download_confirm_btn.Enabled = false
        end
        pcall(function() qwen_download_window:Show() end)
        show_qwen_status(inspect_local_qwen(resolve_asr_paths()))
    end

    function qwen_download_window.On.GenerateQwenDownloadConfirmBtn.Clicked(ev)
        local draft_tracks = {}
        for _, row in ipairs(track_rows) do
            if row.checked then draft_tracks[#draft_tracks + 1] = row.source.track_index end
        end
        refresh_reference()
        runtime_options.reference_text = reference_text
        runtime_options.reference_enabled = reference_enabled
        runtime_options.model_center_draft = {
            last_engine_backend = read_selected_backend(), doubao_backend = selected_doubao_backend,
            max_chars = read_selected_max_chars(), hotwords_enabled = hotwords_enabled,
            audio_track_count = #audio_sources, selected_audio_tracks = draft_tracks
        }
        qwen_install_requested = true
        pcall(function() qwen_download_window:Hide() end)
        pcall(function() selection_window:Hide() end)
        pcall(function() dispatcher:ExitLoop() end)
    end

    function qwen_download_window.On.GenerateQwenDownloadCancelBtn.Clicked(ev)
        pcall(function() qwen_download_window:Hide() end)
    end

    function qwen_download_window.On.GenerateQwenDownloadWindow.Close(ev)
        pcall(function() qwen_download_window:Hide() end)
    end

    -- 秒级近似双击：Resolve 按钮无原生双击事件，用相邻两次点击的秒差(<=阈值)近似。
    local DOUBAO_DOUBLE_CLICK_SECONDS = 1
    local last_doubao_click_time = nil
    local last_qwen_click_time = nil
    local doubao_reminder_shown = false

    -- 轨道数量一致时按轨道编号恢复，避免将勾选套到不同的列表行。
    local restored_tracks, has_restored_track = {}, false
    local full_timeline = scope.source == "full_timeline"
    if (not full_timeline or runtime_options.model_center_draft)
        and generate_preferences.audio_track_count == #audio_sources
        and type(generate_preferences.selected_audio_tracks) == "table" then
        for _, track_index in ipairs(generate_preferences.selected_audio_tracks) do
            if type(track_index) == "number" and track_index > 0 and track_index % 1 == 0 then
                restored_tracks[track_index] = true
            end
        end
        for _, source in ipairs(audio_sources) do
            if restored_tracks[source.track_index] then has_restored_track = true end
        end
    end

    local item_map = {}
    for index, source in ipairs(audio_sources) do
        local ok_item, item = pcall(function() return track_tree:NewItem() end)
        if ok_item and item then
            local checked = full_timeline or index == 1
            if has_restored_track then checked = restored_tracks[source.track_index] == true end
            track_rows[index] = {source = source, checked = checked, item = item}
            set_tree_item_text(item, 0, checked and TRACK_CHECKED_MARK or TRACK_UNCHECKED_MARK)
            set_tree_item_text(item, 1, format_audio_source_label(source, fps))
            pcall(function() track_tree:AddTopLevelItem(item) end)
            item_map[item] = index
        end
    end
    safe_refresh_tree_widget(track_tree)

    local function collect_checked_audio_sources()
        local checked_sources = {}
        for _, row in ipairs(track_rows) do
            if row.checked then
                checked_sources[#checked_sources + 1] = row.source
            end
        end
        return checked_sources
    end

    local function set_track_checked(row, checked)
        row.checked = checked == true
        set_tree_item_text(row.item, 0, row.checked and TRACK_CHECKED_MARK or TRACK_UNCHECKED_MARK)
    end

    -- 现场模式支持多麦：点击即切换该轨勾选状态（单轨场景自然退化为单选）
    function selection_window.On.GenerateAudioTrackTree.ItemClicked(ev)
        local item = get_tree_event_value(ev, {"item", "Item", "currentItem", "CurrentItem"})
        if not item then item = get_selected_tree_node(track_tree) end
        if not item then return end
        local row_index = item_map[item]
        if row_index and track_rows[row_index] then
            set_track_checked(track_rows[row_index], not track_rows[row_index].checked)
            safe_refresh_tree_widget(track_tree)
        end
    end

    -- 字幕长度：两个互斥按钮，点击即切换选中项并高亮当前选择
    function selection_window.On.GenerateSubtitleLengthStandardBtn.Clicked(ev)
        select_subtitle_length(1)
    end

    function selection_window.On.GenerateSubtitleLengthShortBtn.Clicked(ev)
        select_subtitle_length(2)
    end

    -- 识别模型：两个主入口互斥；豆包入口使用配置窗中已保存的具体版本。
    function selection_window.On.GenerateSubtitleEngineQwenBtn.Clicked(ev)
        local now = os.time()
        local is_double = last_qwen_click_time ~= nil and (now - last_qwen_click_time) <= DOUBAO_DOUBLE_CLICK_SECONDS
        last_qwen_click_time = now
        select_subtitle_engine(1)
        if is_double then
            last_qwen_click_time = nil
            open_qwen_download_dialog()
        end
    end

    function selection_window.On.GenerateSubtitleEngineDoubaoBtn.Clicked(ev)
        -- 单击选中豆包；≤阈值秒内的第二次点击视为双击 → 打开配置窗；单次点击时
        -- 若未配置且本次会话还没提醒过，弹提醒窗引导用户双击去配置。
        local now = os.time()
        local is_double = last_doubao_click_time ~= nil and (now - last_doubao_click_time) <= DOUBAO_DOUBLE_CLICK_SECONDS
        last_doubao_click_time = now
        select_subtitle_engine(2)
        if is_double then
            last_doubao_click_time = nil
            pcall(function() doubao_reminder_window:Hide() end)
            open_doubao_key_dialog()
        elseif not doubao_credentials_configured() and not doubao_reminder_shown then
            doubao_reminder_shown = true
            pcall(function() doubao_reminder_window:Show() end)
        end
    end

    function selection_window.On.GenerateSelectionConfirmBtn.Clicked(ev)
        if not reference_fits() then return end
        remember_reference()
        selected_audio_sources = collect_checked_audio_sources()
        if #selected_audio_sources < 1 then
            selected_audio_sources = nil
            if items and items.GenerateSelectionInfoLabel then
                items.GenerateSelectionInfoLabel.Text = "现场模式至少选择一条音频轨道"
            end
            return
        end
        selected_max_chars = read_selected_max_chars()
        selected_backend = read_selected_backend()
        selected_hotwords_json = hotwords_enabled and resolve_asr_paths().hotwords or nil
        if selected_backend == "auto" then
            local qwen_status = inspect_local_qwen(resolve_asr_paths())
            if not qwen_status.ready or not file_exists(qwen_status.aligner or "") then
                runtime_options.model_center_focus = nil
                open_qwen_download_dialog()
                return
            end
        end
        -- 记住本次生成选项，下次打开对话框时恢复。
        local selected_audio_tracks = {}
        for _, source in ipairs(selected_audio_sources) do
            selected_audio_tracks[#selected_audio_tracks + 1] = source.track_index
        end
        local remembered_track_count = not full_timeline and #audio_sources or nil
        save_last_engine_backend(selected_backend, selected_max_chars, hotwords_enabled, remembered_track_count, selected_audio_tracks)
        pcall(function() selection_window:Hide() end)
        pcall(function() dispatcher:ExitLoop() end)
    end

    function selection_window.On.GenerateSelectionCancelBtn.Clicked(ev)
        if refresh_reference() <= 10000 then remember_reference() end
        dialog_cancelled = true
        selected_audio_sources = nil
        pcall(function() selection_window:Hide() end)
        pcall(function() dispatcher:ExitLoop() end)
    end

    function selection_window.On.GenerateSelectionWindow.Close(ev)
        if refresh_reference() <= 10000 then remember_reference() end
        dialog_cancelled = true
        selected_audio_sources = nil
        pcall(function() selection_window:Hide() end)
        pcall(function() dispatcher:ExitLoop() end)
    end

    selection_window:Show()
    dispatcher:RunLoop()
    pcall(function() selection_window:Hide() end)
    pcall(function() reference_window:Hide() end)
    pcall(function() doubao_key_window:Hide() end)
    pcall(function() doubao_reminder_window:Hide() end)
    pcall(function() qwen_download_window:Hide() end)
    pcall(function() if hotword_library_window then hotword_library_window:Hide() end end)
    pcall(function() if hotword_clear_confirm_window then hotword_clear_confirm_window:Hide() end end)

    if qwen_install_requested then
        return nil, nil, nil, nil, nil, "__subfix_model_center__"
    end

    if not selected_audio_sources and not dialog_cancelled then
        selected_audio_sources = collect_checked_audio_sources()
        selected_max_chars = read_selected_max_chars()
        selected_backend = read_selected_backend()
        selected_hotwords_json = hotwords_enabled and resolve_asr_paths().hotwords or nil
        if #selected_audio_sources > 0 then
            print("[SubFix Generate] 音频轨选择窗口提前退出，使用默认勾选轨道")
        end
    end

    if not selected_audio_sources then
        return nil, nil, nil, nil, nil, "已取消"
    end
    if #selected_audio_sources == 0 then
        return nil, nil, nil, nil, nil, "请至少选择一个音频轨道"
    end
    if refresh_reference() > 10000 and reference_enabled then return nil, nil, nil, nil, nil, "参考文稿过长" end
    runtime_options.reference_text = reference_enabled and reference_text or ""
    return selected_audio_sources, subtitle_mode, selected_max_chars, selected_backend, selected_hotwords_json, nil
end

local function progress_elapsed_text(started_at)
    local elapsed = math.max(0, os.time() - (tonumber(started_at) or os.time()))
    if elapsed >= 60 then
        return string.format("%dm%02ds", math.floor(elapsed / 60), math.floor(elapsed % 60))
    end
    return string.format("%ds", math.floor(elapsed + 0.5))
end

local function parse_progress_payload(progress_text)
    local text = tostring(progress_text or "")
    if text == "" then return nil end
    local function number_field(name)
        return tonumber(text:match('"' .. name .. '"%s*:%s*([%d%.%-]+)'))
    end
    return {
        stage = text:match('"stage"%s*:%s*"([^"]*)"') or "",
        message = text:match('"message"%s*:%s*"([^"]*)"') or "",
        batch_index = number_field("batch_index"),
        total_batches = number_field("total_batches"),
        progress_index = number_field("progress_index"),
        progress_total = number_field("progress_total"),
        eta_seconds = number_field("eta_seconds"),
        elapsed_seconds = number_field("elapsed_seconds"),
        indeterminate = text:match('"indeterminate"%s*:%s*true') ~= nil
    }
end

local function progress_bar_text(progress_state, payload)
    if payload and payload.indeterminate then
        local width = GENERATE_PROGRESS_BAR_WIDTH
        local elapsed_seconds = math.max(0, os.time() - (tonumber(progress_state.started_at) or os.time()))
        local phase = elapsed_seconds % width + 1
        local cells = {}
        for cell_index = 1, width do
            cells[#cells + 1] = cell_index == phase and "ᗧ" or "□"
        end
        return table.concat(cells) .. "⚑", 0
    end
    local total = tonumber(payload and payload.progress_total)
    local index = tonumber(payload and payload.progress_index)
    if not total or not index or total <= 0 then
        total = tonumber(payload and payload.total_batches)
        index = tonumber(payload and payload.batch_index)
    end
    local fraction = 0
    if total and index and total > 0 then
        fraction = math.max(0, math.min(1, index / total))
    end
    local stage = tostring(payload and payload.stage or "")
    if stage ~= "完成" and stage ~= "已取消" and stage ~= "失败" then
        fraction = math.min(fraction, 0.98)
    end
    progress_state.progress_total = 100
    progress_state.progress_fraction = math.max(tonumber(progress_state.progress_fraction) or 0, fraction)
    local width = GENERATE_PROGRESS_BAR_WIDTH
    local percent = math.floor(progress_state.progress_fraction * 100 + 0.5)
    if progress_state.progress_fraction >= 0.995 then
        return string.rep("■", width) .. "⚑", percent
    end
    local pacman_pos = math.floor(progress_state.progress_fraction * width + 0.5)
    pacman_pos = math.max(1, math.min(width, pacman_pos))
    local cells = {}
    for cell_index = 1, width do
        if cell_index < pacman_pos then
            cells[#cells + 1] = "■"
        elseif cell_index == pacman_pos then
            cells[#cells + 1] = "ᗧ"
        else
            cells[#cells + 1] = "□"
        end
    end
    return table.concat(cells) .. "⚑", percent
end

local function progress_eta_text(seconds)
    local remaining = math.max(0, math.floor(tonumber(seconds) or 0))
    if remaining >= 60 then
        return string.format("%dm%02ds", math.floor(remaining / 60), remaining % 60)
    end
    return string.format("%ds", remaining)
end

local function show_generate_progress_window()
    if not dispatcher or not ui then
        return nil, "无法初始化 Resolve UI"
    end
    local progress_window = dispatcher:AddWindow({
        ID = "GenerateProgressWindow",
        WindowTitle = "SubFix · 正在生成选区字幕",
        Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({520, 380, 430, 200}),
    },
    ui:VGroup{
        Spacing = 8,
        ContentsMargins = 20,
        ui:Label{ID = "GenerateProgressStatusLabel", Text = "准备中", Weight = 0, MinimumSize = {0, 22}},
        ui:HGroup{
            Weight = 0,
            ui:HGap(0, 1),
            ui:Label{ID = "GenerateProgressBarLabel", Text = "ᗧ" .. string.rep("□", GENERATE_PROGRESS_BAR_WIDTH - 1) .. "⚑", Weight = 0, MinimumSize = {0, 20}},
            ui:HGap(0, 1)
        },
        ui:Label{ID = "GenerateProgressMetaLabel", Text = "进度 0%  ·  用时 0s", Weight = 0, MinimumSize = {0, 18}},
        ui:HGroup{
            Weight = 0,
            ui:HGap(0, 1),
            ui:Label{ID = "GenerateProgressHintLabel", Text = "去摸个鱼吧🐟～\n::)", Weight = 0, MinimumSize = {0, 38}, Alignment = {AlignHCenter = true, AlignVCenter = true}},
            ui:HGap(0, 1)
        },
        ui:VGap(4),
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            ui:HGap(0, 1),
            ui:Button{ID = "GenerateProgressCancelBtn", Text = "取消", Weight = 0, MinimumSize = {88, 28}},
            ui:HGap(0, 1)
        }
    })
    local progress_state = {
        window = progress_window,
        cancel_requested = false,
        cancel_allowed = true,
        started_at = os.time(),
        progress_fraction = 0,
        finished = false
    }

    function progress_window.On.GenerateProgressCancelBtn.Clicked(ev)
        if progress_state.finished then
            progress_window:Hide()
            return
        end
        if progress_state.cancel_allowed == false then return end
        progress_state.cancel_requested = true
    end

    function progress_window.On.GenerateProgressWindow.Close(ev)
        if progress_state.finished then
            progress_window:Hide()
            return
        end
        if progress_state.cancel_allowed == false then return end
        progress_state.cancel_requested = true
    end

    progress_window:Show()
    return progress_state
end

local function update_generate_progress_window(progress_state, payload, extra_log)
    local progress_window = progress_state and progress_state.window
    if not progress_window then return end
    local ok_items, items = pcall(function() return progress_window:GetItems() end)
    if not ok_items or not items then return end
    local stage = tostring(payload and payload.stage or "处理中")
    local message = tostring(payload and payload.message or "")
    local elapsed = progress_elapsed_text(progress_state.started_at)
    local bar, percent = progress_bar_text(progress_state, payload)
    local status_text = message ~= "" and message or stage
    if extra_log and extra_log ~= "" then
        status_text = tostring(extra_log)
    end
    if items.GenerateProgressStatusLabel then items.GenerateProgressStatusLabel.Text = status_text end
    if items.GenerateProgressBarLabel then items.GenerateProgressBarLabel.Text = bar end
    if items.GenerateProgressMetaLabel then
        if payload and payload.indeterminate then
            items.GenerateProgressMetaLabel.Text = "正在进行中  ·  用时 " .. elapsed
        else
            items.GenerateProgressMetaLabel.Text = "进度 " .. tostring(percent) .. "%  ·  用时 " .. elapsed
            if payload and tonumber(payload.eta_seconds) and tonumber(payload.eta_seconds) > 0 then
                items.GenerateProgressMetaLabel.Text = items.GenerateProgressMetaLabel.Text .. "  ·  预计剩余 " .. progress_eta_text(payload.eta_seconds)
            end
        end
    end
end

local function set_generate_progress_cancel_enabled(progress_state, enabled, text)
    if not progress_state then return end
    progress_state.cancel_allowed = enabled ~= false
    local progress_window = progress_state.window
    if not progress_window then return end
    local ok_items, items = pcall(function() return progress_window:GetItems() end)
    if not ok_items or not items or not items.GenerateProgressCancelBtn then return end
    items.GenerateProgressCancelBtn.Enabled = enabled ~= false
    if text and text ~= "" then
        items.GenerateProgressCancelBtn.Text = tostring(text)
    end
end

local function pump_generate_progress_events(progress_state)
    if not dispatcher or not ui then
        return not (progress_state and progress_state.cancel_requested)
    end
    local uid = tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999))
    local timer_id = "GenerateProgressYieldTimer_" .. uid
    local yield_timer = ui:Timer({
        ID = timer_id,
        Interval = GENERATE_UI_YIELD_INTERVAL_MS,
        SingleShot = true
    })
    local timer_registered = register_ui_timer(yield_timer, function()
        pcall(function() yield_timer:Stop() end)
        ui_timer_handlers[timer_id] = nil
        pcall(function() dispatcher:ExitLoop() end)
    end)
    if not timer_registered then
        return not (progress_state and progress_state.cancel_requested)
    end
    local started = pcall(function() yield_timer:Start() end)
    if not started then
        ui_timer_handlers[timer_id] = nil
        return not (progress_state and progress_state.cancel_requested)
    end
    pcall(function() dispatcher:RunLoop() end)
    pcall(function() yield_timer:Stop() end)
    ui_timer_handlers[timer_id] = nil
    return not (progress_state and progress_state.cancel_requested)
end

local function update_generate_postprocess_stage(progress_state, stage, message, progress_index)
    update_generate_progress_window(progress_state, {
        stage = stage,
        message = message,
        progress_index = progress_index,
        progress_total = 100
    }, message)
    return pump_generate_progress_events(progress_state)
end

local function show_writeback_progress_overlay(progress_state)
    local progress_window = progress_state and progress_state.window
    if not progress_window then return false end
    local ok = pcall(function()
        progress_window:SetAttrs({Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry(GENERATE_WRITEBACK_OVERLAY_GEOMETRY)})
        progress_window:Show()
    end)
    return ok
end

local function finish_generate_progress_window(progress_state, status, message)
    local progress_window = progress_state and progress_state.window
    if not progress_window then return end
    local payload = {stage = status, message = message}
    if status == "完成" then
        payload.progress_index = 100
        payload.progress_total = 100
    end
    update_generate_progress_window(progress_state, payload, message)
    progress_state.finished = true
    set_generate_progress_cancel_enabled(progress_state, true, "关闭")
end

local function summarize_doubao_asr_failure_reason(reason)
    local text = trim_text(tostring(reason or "豆包 ASR 请求失败"))
    text = text:gsub("[\r\n]+", " ")
    local marker_start, marker_end = text:find("豆包 ASR 失败", 1, true)
    if marker_start then
        text = trim_text(text:sub(marker_end + 1):gsub("^[（(][^）)]*[）)]%s*[:：]?%s*", ""))
    end
    if text == "" then text = "豆包 ASR 请求失败" end
    if #text > 180 then text = text:sub(1, 177) .. "..." end
    return text
end

local function is_doubao_asr_failure(reason)
    return tostring(reason or ""):find("豆包 ASR 失败", 1, true) ~= nil
end

-- 云端请求失败不再静默回退：先给出原始原因，再由用户决定是否重试或改用本地 Qwen。
-- 该窗口运行时没有后台轮询 RunLoop，因此独立 RunLoop 不会嵌套进进度计时器。
local function show_doubao_asr_failure_action_dialog(reason)
    if not dispatcher or not ui then return "close" end
    local action = "close"
    local dialog = dispatcher:AddWindow({
        ID = "GenerateDoubaoAsrFailureWindow",
        WindowTitle = "SubFix · 云端识别失败",
        Geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry({520, 320, 520, 300}),
    },
    ui:VGroup{
        Spacing = 8,
        ContentsMargins = 12,
        ui:Label{Text = "豆包（云端）未完成识别：", Weight = 0},
        ui:TextEdit{
            ID = "GenerateDoubaoAsrFailureReason",
            Text = summarize_doubao_asr_failure_reason(reason),
            ReadOnly = true,
            Weight = 1,
            MinimumSize = {0, 84}
        },
        ui:VGap(2),
        ui:HGroup{
            Weight = 0,
            Spacing = 8,
            MinimumSize = {0, 44},
            ui:Button{ID = "GenerateDoubaoAsrRetryBtn", Text = "重试", Weight = 1, MinimumSize = {0, 28}},
            ui:Button{ID = "GenerateDoubaoAsrUseQwenBtn", Text = "改用本地 Qwen", Weight = 1, MinimumSize = {0, 28}},
            ui:Button{ID = "GenerateDoubaoAsrCloseBtn", Text = "关闭", Weight = 1, MinimumSize = {0, 28}}
        }
    })

    local function finish(choice)
        action = choice or "close"
        pcall(function() dialog:Hide() end)
        pcall(function() dispatcher:ExitLoop() end)
    end
    function dialog.On.GenerateDoubaoAsrRetryBtn.Clicked(ev) finish("retry") end
    function dialog.On.GenerateDoubaoAsrUseQwenBtn.Clicked(ev) finish("local_qwen") end
    function dialog.On.GenerateDoubaoAsrCloseBtn.Clicked(ev) finish("close") end
    function dialog.On.GenerateDoubaoAsrFailureWindow.Close(ev) finish("close") end

    dialog:Show()
    dispatcher:RunLoop()
    pcall(function() dialog:Hide() end)
    return action
end

local GENERATE_ENGINE_PROFILE_FILES = {
    v5 = "segmentation_profile_v4.json",
}

local function resolve_generate_engine()
    return "v5"
end

local function resolve_segmentation_profile_path(paths, engine)
    local file_name = GENERATE_ENGINE_PROFILE_FILES[engine]
    if not file_name then return nil end
    local helper_dir = tostring(paths.helper or ""):match("^(.*)/[^/]+$")
    local candidates = {}
    if helper_dir then candidates[#candidates + 1] = helper_dir .. "/" .. file_name end
    candidates[#candidates + 1] = configured_script_root() .. "/.subfix_support/" .. file_name
    for _, candidate in ipairs(candidates) do
        if candidate and file_exists(candidate) then return candidate end
    end
    print(string.format("[SubFix Generate] 未找到 %s 引擎的断句 profile (%s)，交由 Python 默认路径处理", engine, file_name))
    return nil
end

local function build_asr_helper_command(audio_source, srt_path, json_path, timeline_start_frame, fps, progress_path)
    local paths = resolve_asr_paths()
    if not file_exists(paths.helper) then
        return nil, "缺少 ASR helper: " .. tostring(paths.helper)
    end
    if not file_exists(paths.python) then
        return nil, "ASR 环境未安装，请先运行: " .. tostring(paths.setup)
    end
    local generate_engine = resolve_generate_engine()
    local cmd_parts = {
        shell_quote(paths.python),
        shell_quote(paths.helper),
        "--mode", "generate_subtitles",
        "--backend", shell_quote(DEFAULT_ASR_BACKEND),
        "--generate-engine", shell_quote(generate_engine),
        "--audio", shell_quote(audio_source.file_path),
        "--output", shell_quote(json_path),
        "--srt-output", shell_quote(srt_path),
        "--srt-base-frame", shell_quote(tostring(timeline_start_frame)),
        "--timeline-start-frame", shell_quote(tostring(audio_source.start_frame)),
        "--fps", shell_quote(tostring(fps)),
        "--model", shell_quote(DEFAULT_ASR_MODEL),
        "--language", shell_quote(DEFAULT_ASR_LANGUAGE),
        "--progress-json", shell_quote(progress_path),
        "--source-start", shell_quote(string.format("%.3f", tonumber(audio_source.source_start_seconds) or 0)),
        "--source-end", shell_quote(string.format("%.3f", tonumber(audio_source.source_end_seconds) or 0))
    }
    local audio_channel_index = tonumber(audio_source.audio_channel_index)
    if audio_channel_index and audio_channel_index > 0 then
        cmd_parts[#cmd_parts + 1] = "--audio-channel-index"
        cmd_parts[#cmd_parts + 1] = shell_quote(tostring(math.floor(audio_channel_index)))
    end
    local profile_path = resolve_segmentation_profile_path(paths, generate_engine)
    if profile_path then
        cmd_parts[#cmd_parts + 1] = "--segmentation-profile"
        cmd_parts[#cmd_parts + 1] = shell_quote(profile_path)
    end
    return table.concat(cmd_parts, " "), nil
end

local function build_asr_helper_batch_command(batch_plan_path, srt_path, json_path, timeline_start_frame, fps, progress_path, subtitle_mode, max_chars, backend, hotwords_json, reference_path)
    local paths = resolve_asr_paths()
    if not file_exists(paths.helper) then
        return nil, "缺少 ASR helper: " .. tostring(paths.helper)
    end
    subtitle_mode = subtitle_mode == "live" and "live" or "narration"
    -- backend 由生成对话框的"识别模型"选择决定；缺省回退到 DEFAULT_ASR_BACKEND(auto/Qwen 本地)。
    local asr_backend = (type(backend) == "string" and backend ~= "") and backend or DEFAULT_ASR_BACKEND
    if asr_backend == "auto" then asr_backend = "qwen3_asr" end
    local qwen_status = {}
    local python = paths.python
    if asr_backend == "doubao_asr" or asr_backend == "doubao_asr_v2" then
        -- 豆包使用原生时间戳及自身的缺失时间戳处理，不依赖本地 Qwen。
        python = paths.runtime_python
        if not file_exists(python) then
            return nil, "SubFix 内置 Python 缺失，请重新安装完整 SubFix 测试版"
        end
    else
        qwen_status = inspect_local_qwen(paths)
        if not file_exists(qwen_status.aligner or "") then
            return nil, "缺少对齐模型，请在模型中心下载或导入 Qwen3-ForcedAligner-0.6B"
        end
        if not (qwen_status.ready and file_exists(qwen_status.python or "")) then
            return nil, "所选本地模型尚未就绪，请在模型中心下载、导入或补全运行环境"
        end
        python = qwen_status.python
    end
    local generate_engine = resolve_generate_engine()
    local cmd_parts = {}
    if asr_backend == "auto" or asr_backend == "qwen3_asr" then
        cmd_parts[#cmd_parts + 1] = "SUBFIX_QWEN3_ALIGNER_GGUF=" .. shell_quote(qwen_status.aligner)
        cmd_parts[#cmd_parts + 1] = "SUBFIX_QWEN3_ASR_MODEL=" .. shell_quote(qwen_status.model)
    end
    local command_args = {}
    if qwen_status and qwen_status.ready and file_exists(qwen_status.python or "") then
        command_args = {"env", "-u", "PYTHONHOME", "-u", "PYTHONPATH"}
    end
    local helper_args = {
        shell_quote(python),
        shell_quote(paths.helper),
        "--mode", "generate_subtitles_batch",
        "--backend", shell_quote(asr_backend),
        "--generate-engine", shell_quote(generate_engine),
        "--batch-plan-json", shell_quote(batch_plan_path),
        "--output", shell_quote(json_path),
        "--srt-output", shell_quote(srt_path),
        "--srt-base-frame", shell_quote(tostring(timeline_start_frame)),
        "--timeline-start-frame", shell_quote(tostring(timeline_start_frame)),
        "--fps", shell_quote(tostring(fps)),
        "--model", shell_quote(DEFAULT_ASR_MODEL),
        "--language", shell_quote(DEFAULT_ASR_LANGUAGE),
        "--subtitle-mode", shell_quote(subtitle_mode),
        "--diagnostic-output", shell_quote(paths.diagnostic),
        "--plugin-source", shell_quote(paths.plugin_source),
        "--generation-core-source", shell_quote(paths.generation_core_source),
        "--progress-json", shell_quote(progress_path)
    }
    for _, value in ipairs(helper_args) do command_args[#command_args + 1] = value end
    for _, value in ipairs(command_args) do cmd_parts[#cmd_parts + 1] = value end
    max_chars = tonumber(max_chars) or 25
    cmd_parts[#cmd_parts + 1] = "--max-chars"
    cmd_parts[#cmd_parts + 1] = shell_quote(tostring(max_chars))
    local profile_path = resolve_segmentation_profile_path(paths, generate_engine)
    if profile_path then
        cmd_parts[#cmd_parts + 1] = "--segmentation-profile"
        cmd_parts[#cmd_parts + 1] = shell_quote(profile_path)
    end
    if reference_path then
        cmd_parts[#cmd_parts + 1] = "--reference-file"
        cmd_parts[#cmd_parts + 1] = shell_quote(reference_path)
    end
    if hotwords_json and file_exists(hotwords_json) then
        cmd_parts[#cmd_parts + 1] = "--hotwords-json"
        cmd_parts[#cmd_parts + 1] = shell_quote(hotwords_json)
    end
    return table.concat(cmd_parts, " "), nil
end

local function kill_background_process(pid_file)
    local pid_text = trim_text(read_text_file(pid_file) or "")
    local pid = tonumber(pid_text)
    if pid and pid > 0 then
        local paths = resolve_asr_paths()
        if file_exists(paths.runtime_python) and file_exists(paths.process_group) then
            local stop_cmd = table.concat({
                shell_quote(paths.runtime_python),
                shell_quote(paths.process_group),
                "--stop",
                shell_quote(tostring(pid))
            }, " ")
            local stop_status = os.execute(stop_cmd)
            if stop_status == true or stop_status == 0 then
                return
            end
        end
        os.execute("kill -TERM -- -" .. tostring(pid) .. " 2>/dev/null || kill -TERM " .. tostring(pid) .. " 2>/dev/null || true")
        os.execute("sleep 0.2; kill -KILL -- -" .. tostring(pid) .. " 2>/dev/null || true")
    end
end

local function progress_payload_signature(payload)
    return table.concat({
        tostring(payload and payload.stage or ""),
        tostring(payload and payload.message or ""),
        tostring(payload and payload.batch_index or ""),
        tostring(payload and payload.total_batches or ""),
        tostring(payload and payload.progress_index or ""),
        tostring(payload and payload.progress_total or "")
    }, "\n")
end

local function run_background_command_with_progress(cmd, progress_path, progress_state)
    local uid = tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999))
    local root = temp_dir()
    local stdout_file = root .. "/asr_stdout_" .. uid .. ".log"
    local pid_file = root .. "/asr_pid_" .. uid
    local done_file = root .. "/asr_done_" .. uid
    local exit_file = root .. "/asr_exit_" .. uid
    local output = ""
    local cancelled = false
    local paths = resolve_asr_paths()
    if not file_exists(paths.runtime_python) then
        return false, "未找到 SubFix 内置 Python", nil
    end
    local grouped_cmd
    if file_exists(paths.process_group) then
        grouped_cmd = table.concat({
            shell_quote(paths.runtime_python),
            shell_quote(paths.process_group),
            shell_quote(cmd),
        }, " ")
    else
        -- v3.2.0 cannot add new paths, so incremental upgrades need an inline equivalent.
        local process_group_code = [[import os,sys; os.setsid(); os.execl("/bin/sh", "sh", "-c", sys.argv[1])]]
        grouped_cmd = table.concat({
            shell_quote(paths.runtime_python),
            "-c",
            shell_quote(process_group_code),
            shell_quote(cmd),
        }, " ")
    end

    -- Detach the waiting shell too: inherited host pipes can keep launch blocked
    -- until the worker exits, preventing the progress event loop from starting.
    local bg_cmd = string.format(
        "(%s > %s 2>&1 & worker_pid=$!; echo $worker_pid > %s; wait $worker_pid; echo $? > %s; touch %s) </dev/null >/dev/null 2>&1 &",
        grouped_cmd,
        shell_quote(stdout_file),
        shell_quote(pid_file),
        shell_quote(exit_file),
        shell_quote(done_file)
    )
    os.execute(bg_cmd)

    local timer_id = "GenerateProgressPollTimer_" .. uid
    local poll_timer = ui:Timer({ID = timer_id, Interval = 200, SingleShot = false})
    local last_signature = nil
    local last_progress_changed_at = os.time()
    local stall_warning_logged = false
    local started_at = os.time()
    local last_process_check_at = started_at
    local missing_process_checks = 0
    local failed_at = nil
    local terminal_error = nil

    local function stop_polling()
        pcall(function() poll_timer:Stop() end)
        ui_timer_handlers[timer_id] = nil
        pcall(function() dispatcher:ExitLoop() end)
    end

    local timer_registered = register_ui_timer(poll_timer, function()
        local payload = parse_progress_payload(read_text_file(progress_path) or "")
        local signature = progress_payload_signature(payload)
        if signature ~= last_signature then
            last_signature = signature
            last_progress_changed_at = os.time()
            stall_warning_logged = false
        end

        local display_message = tostring(payload and payload.message or "正在识别音频...")
        local stalled_seconds = math.max(0, os.time() - last_progress_changed_at)
        if stalled_seconds >= GENERATE_PROGRESS_STALL_WARNING_SECONDS then
            display_message = display_message .. " · 长时间无新进度，可取消后重试"
            if not stall_warning_logged then
                print(string.format(
                    "[SubFix Generate] ASR 已 %ds 无新进度；任务仍在运行，可由用户安全取消",
                    stalled_seconds
                ))
                stall_warning_logged = true
            end
        end
        update_generate_progress_window(
            progress_state,
            payload or {stage = "处理中", message = "正在识别音频..."},
            display_message
        )

        if progress_state and progress_state.cancel_requested then
            cancelled = true
            kill_background_process(pid_file)
            stop_polling()
            return
        end

        if file_exists(done_file) or tonumber(trim_text(read_text_file(exit_file) or "")) then
            stop_polling()
            return
        end
        if payload and payload.stage == "failed" then
            failed_at = failed_at or os.time()
            -- Let the helper flush its error/output before stopping a stuck wrapper.
            if os.time() - failed_at >= 2 then
                terminal_error = tostring(payload.message or "ASR helper 执行失败")
                kill_background_process(pid_file)
                stop_polling()
                return
            end
        end
        if os.time() - last_process_check_at >= 2 then
            last_process_check_at = os.time()
            local pid = tonumber(trim_text(read_text_file(pid_file) or ""))
            if pid and pid > 0 and pid == math.floor(pid) then
                local alive = os.execute("kill -0 " .. tostring(pid) .. " 2>/dev/null")
                if alive == true or alive == 0 then
                    missing_process_checks = 0
                else
                    missing_process_checks = missing_process_checks + 1
                    if missing_process_checks >= 2 then
                        terminal_error = "ASR helper 已退出，但未返回完成状态；请查看诊断日志"
                        stop_polling()
                    end
                end
            elseif os.time() - started_at >= 10 then
                terminal_error = "ASR helper 启动失败：未取得进程编号；请查看诊断日志"
                stop_polling()
            end
        end
    end)
    if not timer_registered then
        kill_background_process(pid_file)
        return false, "无法启动进度轮询", nil
    end

    update_generate_progress_window(progress_state, {stage = "启动 ASR", message = "正在启动字幕识别..."}, "启动 ASR helper")
    local timer_ok = pcall(function() poll_timer:Start() end)
    if not timer_ok then
        ui_timer_handlers[timer_id] = nil
        kill_background_process(pid_file)
        return false, "无法启动进度窗口计时器", nil
    end
    dispatcher:RunLoop()
    pcall(function() poll_timer:Stop() end)
    ui_timer_handlers[timer_id] = nil

    output = read_text_file(stdout_file) or ""
    local exit_code = tonumber(trim_text(read_text_file(exit_file) or "")) or 1
    local succeeded = exit_code == 0 and not terminal_error
    os.execute(string.format("rm -f %s %s %s 2>/dev/null", shell_quote(pid_file), shell_quote(done_file), shell_quote(exit_file)))
    if succeeded or cancelled then
        os.execute("rm -f " .. shell_quote(stdout_file) .. " 2>/dev/null")
    else
        if terminal_error then output = terminal_error .. "\n" .. output end
        if trim_text(output) == "" then output = "ASR helper 异常退出 (" .. tostring(exit_code) .. ")" end
        output = output .. "\n诊断日志: " .. stdout_file
    end

    if cancelled then
        return false, "已取消", "cancelled"
    end
    return succeeded, output, nil
end

local function run_asr_helper_with_progress(audio_source, srt_path, json_path, timeline_start_frame, fps, progress_state, source_index, source_count)
    local progress_path = json_path .. ".progress.json"
    local cmd, cmd_err = build_asr_helper_command(audio_source, srt_path, json_path, timeline_start_frame, fps, progress_path)
    if not cmd then return false, cmd_err end
    if source_index and source_count then
        update_generate_progress_window(
            progress_state,
            {stage = string.format("识别 %d/%d", tonumber(source_index) or 0, tonumber(source_count) or 0), message = tostring(audio_source.file_name or audio_source.file_path or "")},
            string.format("识别 %d/%d: %s", tonumber(source_index) or 0, tonumber(source_count) or 0, tostring(audio_source.file_name or audio_source.file_path or ""))
        )
    end
    local ok, output, status = run_background_command_with_progress(cmd, progress_path, progress_state)
    os.execute("rm -f " .. shell_quote(progress_path) .. " 2>/dev/null")
    if not ok then
        return false, tostring(output or "ASR helper 执行失败"), status
    end
    if not file_exists(srt_path) then
        return false, "ASR helper 未生成 SRT"
    end
    return true
end

local function selected_sources_effective_audio_seconds(sources, fps)
    local total_seconds = 0
    local effective_fps = math.max(1, tonumber(fps) or 24)
    for _, source in ipairs(sources or {}) do
        local source_start = tonumber(source and source.source_start_seconds)
        local source_end = tonumber(source and source.source_end_seconds)
        local duration = source_start and source_end and (source_end - source_start) or 0
        if duration <= 0 then
            duration = (
                (tonumber(source and source.end_frame) or 0) -
                (tonumber(source and source.start_frame) or 0)
            ) / effective_fps
        end
        total_seconds = total_seconds + math.max(0, duration)
    end
    return total_seconds
end

local function format_generate_audio_duration(seconds)
    local total = math.max(0, math.floor((tonumber(seconds) or 0) + 0.5))
    local hours = math.floor(total / 3600)
    local minutes = math.floor((total % 3600) / 60)
    local remaining_seconds = total % 60
    if hours > 0 then
        return string.format("%dh%02dm%02ds", hours, minutes, remaining_seconds)
    end
    if minutes > 0 then
        return string.format("%dm%02ds", minutes, remaining_seconds)
    end
    return string.format("%ds", remaining_seconds)
end

local function run_asr_helper_batch_with_progress(batch_plan_path, srt_path, json_path, timeline_start_frame, fps, progress_state, source_count, subtitle_mode, max_chars, backend, hotwords_json, effective_audio_seconds)
    local progress_path = json_path .. ".progress.json"
    local cmd, cmd_err = build_asr_helper_batch_command(batch_plan_path, srt_path, json_path, timeline_start_frame, fps, progress_path, subtitle_mode, max_chars, backend, hotwords_json, runtime_options.reference_path)
    if not cmd then return false, cmd_err end
    local duration_text = format_generate_audio_duration(effective_audio_seconds)
    update_generate_progress_window(
        progress_state,
        {stage = "启动批量 ASR", message = string.format("准备识别 %d 段音频 · 有效音频 %s", tonumber(source_count) or 0, duration_text)},
        string.format("批量识别 %d 段音频 · 有效音频 %s", tonumber(source_count) or 0, duration_text)
    )
    local ok, output, status = run_background_command_with_progress(cmd, progress_path, progress_state)
    os.execute("rm -f " .. shell_quote(progress_path) .. " 2>/dev/null")
    if not ok then
        return false, tostring(output or "ASR helper 执行失败"), status
    end
    if not file_exists(json_path) then
        return false, "ASR helper 未生成 JSON"
    end
    return true
end

local function model_center_query(action, model_id)
    local paths = resolve_asr_paths()
    local uid = tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999))
    local output_path = temp_dir() .. "/subfix_models_" .. uid .. ".json"
    local cmd, err = build_qwen_status_command(paths, output_path)
    if not cmd then return nil, err end
    cmd = cmd:gsub("%-%-action status", "--action " .. action)
    if model_id then cmd = cmd .. " --model-id " .. shell_quote(model_id) end
    os.execute(cmd .. " >/dev/null 2>&1")
    local payload = decode_json_text(read_text_file(output_path) or "")
    os.remove(output_path)
    if type(payload) ~= "table" then return nil, "模型状态读取失败，请重试或安装最新完整包" end
    if payload.ok == false or payload.error then return nil, tostring(payload.error or "模型操作失败") end
    return payload
end

local function perform_model_center_action(action)
    if action.kind == "select" then return model_center_query("select", action.model_id) end
    local paths = resolve_asr_paths()
    local uid = tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999))
    local output_path = temp_dir() .. "/subfix_model_task_" .. uid .. ".json"
    local progress_path = output_path .. ".progress.json"
    local cmd = table.concat({
        "env", "PYTHONDONTWRITEBYTECODE=1", shell_quote(paths.runtime_python), "-B", shell_quote(paths.qwen_manager),
        "--action", shell_quote(action.kind), "--model-id", shell_quote(action.model_id),
        "--source", shell_quote(action.source or "auto"),
        "--output", shell_quote(output_path), "--progress-json", shell_quote(progress_path)
    }, " ")
    if action.kind == "import" then cmd = cmd .. " --input-path " .. shell_quote(action.input_path) end
    local progress_state, progress_err = show_generate_progress_window()
    if not progress_state then return nil, progress_err end
    pcall(function() progress_state.window.WindowTitle = "SubFix · 模型准备" end)
    local ok, output, status = run_background_command_with_progress(cmd, progress_path, progress_state)
    local payload = decode_json_text(read_text_file(output_path) or "")
    os.remove(output_path)
    os.remove(progress_path)
    pcall(function() progress_state.window:Hide() end)
    if status == "cancelled" then return nil, "已取消。已完成的下载缓存会保留，可稍后重试。" end
    if not ok or type(payload) ~= "table" or payload.ok == false or payload.error then
        return nil, tostring(type(payload) == "table" and payload.error or output or "操作失败，请重试或改用离线导入。")
    end
    return payload
end

local function open_model_center(focus_model_id)
    local paths = resolve_asr_paths()
    if not file_exists(paths.qwen_manager) then return false, "模型中心组件缺失，请安装最新完整 SubFix 安装包" end
    local ui_path = paths.qwen_manager:gsub("subfix_model_manager%.py$", "subfix_model_center.lua")
    local chunk, err = loadfile(ui_path)
    if not chunk then return false, "模型中心界面缺失，请安装最新完整 SubFix 安装包：" .. tostring(err) end
    local loaded, center = pcall(chunk)
    if not loaded or type(center) ~= "table" or type(center.open) ~= "function" then
        return false, "模型中心无法加载，请安装最新完整 SubFix 安装包"
    end
    if not ui or not dispatcher then return false, "无法初始化 Resolve UI" end
    local ok, result = pcall(center.open, {
        ui = ui, dispatcher = dispatcher, geometry = SUBFIX_WINDOW_GEOMETRY.centered_geometry,
        focus_model_id = focus_model_id, query = model_center_query, perform = perform_model_center_action,
        browse = function(directory)
            if directory then return fusion_app:RequestDir("") end
            return fusion_app:RequestFile("", "*.gguf")
        end
    })
    return ok and result == true, not ok and tostring(result) or nil
end

function SubFixGenerateSelectionCore.open_model_center(options)
    runtime_options = options or {}
    local ok, err = open_model_center(runtime_options.focus_model_id)
    runtime_options = {}
    return ok, err
end

function SubFixGenerateSelectionCore.ensure_alignment_model(options)
    runtime_options = options or {}
    local status = inspect_local_qwen(resolve_asr_paths())
    if not file_exists(status.aligner or "") then
        local ok, err = open_model_center("qwen3-forced-aligner-0.6b")
        if not ok then runtime_options = {}; return false, err end
        status = inspect_local_qwen(resolve_asr_paths())
    end
    runtime_options = {}
    if not file_exists(status.aligner or "") then return false, "对齐模型尚未就绪，请在模型中心下载或导入后再试" end
    return true
end

local function parse_generated_srt_rows(srt_path, fps, base_frame)
    local file = io.open(tostring(srt_path or ""), "r")
    if not file then return nil, "无法读取生成的 SRT" end
    local lines = {}
    for line in file:lines() do
        lines[#lines + 1] = line
    end
    file:close()

    local rows = {}
    local index = 1
    while index <= #lines do
        local timing = tostring(lines[index] or "")
        local start_time, end_time = timing:match("^(%d+:%d+:%d+,%d+)%s+%-%-%>%s+(%d+:%d+:%d+,%d+)")
        if not start_time and index < #lines then
            index = index + 1
            timing = tostring(lines[index] or "")
            start_time, end_time = timing:match("^(%d+:%d+:%d+,%d+)%s+%-%-%>%s+(%d+:%d+:%d+,%d+)")
        end
        if start_time and end_time then
            local text_lines = {}
            index = index + 1
            while index <= #lines and tostring(lines[index] or "") ~= "" do
                text_lines[#text_lines + 1] = tostring(lines[index] or "")
                index = index + 1
            end
            local start_frame = srt_time_to_frame(start_time, fps, base_frame)
            local end_frame = srt_time_to_frame(end_time, fps, base_frame)
            if start_frame and end_frame and table.concat(text_lines, "") ~= "" then
                rows[#rows + 1] = {
                    index = #rows + 1,
                    start_frame = start_frame,
                    end_frame = math.max(end_frame, start_frame + 1),
                    text = table.concat(text_lines, "\n")
                }
            end
        end
        index = index + 1
    end
    if #rows == 0 then return nil, "生成的 SRT 没有可写回字幕" end
    return rows
end

local function merge_generated_rows_for_writeback(row_groups, scope)
    local all_rows = {}
    local scope_start = tonumber(scope and scope.start_frame)
    local scope_end = tonumber(scope and scope.end_frame)
    for _, rows in ipairs(row_groups or {}) do
        for _, row in ipairs(rows or {}) do
            local start_frame = tonumber(row.start_frame)
            local end_frame = tonumber(row.end_frame)
            local text = trim_text(tostring(row.text or ""))
            if start_frame and end_frame and text ~= "" then
                if scope_start then start_frame = math.max(start_frame, scope_start) end
                if scope_end then end_frame = math.min(end_frame, scope_end) end
                if end_frame > start_frame then
                    all_rows[#all_rows + 1] = {
                        start_frame = start_frame,
                        end_frame = end_frame,
                        text = text
                    }
                end
            end
        end
    end
    table.sort(all_rows, function(a, b)
        local a_start = tonumber(a.start_frame) or 0
        local b_start = tonumber(b.start_frame) or 0
        if a_start ~= b_start then return a_start < b_start end
        return (tonumber(a.end_frame) or 0) < (tonumber(b.end_frame) or 0)
    end)

    local merged_rows = {}
    local last_end = nil
    for _, row in ipairs(all_rows) do
        local start_frame = tonumber(row.start_frame) or 0
        local end_frame = tonumber(row.end_frame) or 0
        if last_end and start_frame < last_end then
            start_frame = last_end
        end
        if end_frame > start_frame then
            merged_rows[#merged_rows + 1] = {
                index = #merged_rows + 1,
                start_frame = start_frame,
                end_frame = end_frame,
                text = row.text
            }
            last_end = end_frame
        end
    end
    if #merged_rows == 0 then
        return nil, "生成结果没有可写回字幕"
    end
    return merged_rows
end

local function build_composite_rows_for_writeback(existing_rows, scope, generated_rows)
    local rows = {}
    for _, existing_row in ipairs(existing_rows or {}) do
        local start_frame = tonumber(existing_row.start_frame) or 0
        local end_frame = tonumber(existing_row.end_frame) or 0
        if not range_intersects_selection(start_frame, end_frame, scope) then
            rows[#rows + 1] = {
                start_frame = start_frame,
                end_frame = end_frame,
                text = tostring(existing_row.text or "")
            }
        end
    end
    for _, row in ipairs(generated_rows or {}) do
        rows[#rows + 1] = {
            start_frame = tonumber(row.start_frame) or 0,
            end_frame = tonumber(row.end_frame) or 0,
            text = tostring(row.text or "")
        }
    end
    table.sort(rows, function(a, b)
        return (tonumber(a.start_frame) or 0) < (tonumber(b.start_frame) or 0)
    end)
    for row_index, row in ipairs(rows) do
        row.index = row_index
        if (tonumber(row.end_frame) or 0) <= (tonumber(row.start_frame) or 0) then
            row.end_frame = (tonumber(row.start_frame) or 0) + 1
        end
    end
    return rows
end

local function write_rows_to_rebuild_srt(srt_path, rows, fps, base_frame)
    local file = io.open(tostring(srt_path or ""), "w")
    if not file then return false, "无法创建重建字幕 SRT" end
    for index, row in ipairs(rows or {}) do
        file:write(tostring(index) .. "\n")
        file:write(frames_to_srt_time(row.start_frame, fps, base_frame) .. " --> " .. frames_to_srt_time(row.end_frame, fps, base_frame) .. "\n")
        file:write(tostring(row.text or "") .. "\n\n")
    end
    file:close()
    return true
end

local function capture_timeline_playhead_timecode(timeline)
    if not timeline then return nil end
    local ok, timecode = pcall(function() return timeline:GetCurrentTimecode() end)
    if ok and trim_text(timecode) ~= "" then
        return tostring(timecode)
    end
    print("[SubFix Generate] 保存播放头失败: " .. tostring(timecode))
    return nil
end

local function restore_timeline_playhead_timecode(timeline, timecode)
    timecode = trim_text(timecode)
    if not timeline or timecode == "" then return false end
    local ok, ret = pcall(function() return timeline:SetCurrentTimecode(timecode) end)
    if ok and ret ~= false then
        print("[SubFix Generate] 已恢复播放头: " .. tostring(timecode))
        return true
    end
    print("[SubFix Generate] 恢复播放头失败: " .. tostring(ret))
    return false
end

local function cleanup_imported_subtitle_media_item(media_pool, media_pool_item, context)
    if not media_pool or not media_pool_item then
        return false
    end

    local ok, result = pcall(function() return media_pool:DeleteClips({media_pool_item}) end)
    if ok and result ~= false then
        print("[SubFix Generate] " .. tostring(context or "字幕写回") .. "后已清理媒体池临时字幕")
        return true
    end

    print(
        "[SubFix Generate] " .. tostring(context or "字幕写回") ..
        "后清理媒体池临时字幕失败: " .. tostring(result)
    )
    return false
end

local function append_rebuild_srt_to_timeline(media_pool, media_pool_item)
    if not media_pool or not media_pool_item then
        return false, "缺少媒体池或字幕媒体项"
    end

    print("[SubFix Generate] 使用稳定模式追加字幕到时间线")
    local ok_append, ret = pcall(function() return media_pool:AppendToTimeline({media_pool_item}) end)
    if ok_append and ret ~= false and ret ~= nil then
        return true, ret
    end
    return false, "追加重建字幕到时间线失败"
end

local function import_rebuild_srt_with_retry(media_pool, rebuild_srt_path)
    local folder_hint = "；原字幕未清空，请检查媒体夹是否被其他协作者占用，切换到可写媒体夹后重试"
    local folder_ok, folder = pcall(function() return media_pool:GetCurrentFolder() end)
    if not folder_ok or not folder then
        return nil, "无法获取当前媒体夹" .. folder_hint
    end
    local last_error = ""
    for attempt = 1, 2 do
        -- 重试仍使用本次选中的媒体夹，不能回退到可能被协作者锁定的主媒体夹。
        local ok_folder, folder_ret = pcall(function() return media_pool:SetCurrentFolder(folder) end)
        if not ok_folder or folder_ret ~= true then
            return nil, "无法切换到选中的媒体夹" .. folder_hint
        end
        local ok_import, items = pcall(function() return media_pool:ImportMedia({rebuild_srt_path}) end)
        if ok_import and type(items) == "table" and items[1] then
            if attempt > 1 then
                print("[SubFix Generate] 重试导入重建字幕 SRT 成功")
            end
            return items, nil
        end
        last_error = ok_import and "Resolve 返回空媒体项" or tostring(items)
        if attempt < 2 then
            print("[SubFix Generate] 首次导入重建字幕 SRT 失败，准备重试: " .. tostring(last_error))
            os.execute("sleep 0.25")
        end
    end
    return nil, "导入重建字幕 SRT 失败（已重试）: " .. tostring(last_error) .. folder_hint
end

local function rebuild_target_subtitle_track_from_rows(project, timeline, rows, fps, base_frame)
    if not rows or #rows == 0 then return false, "没有可写回字幕" end
    local media_pool = project:GetMediaPool()
    if not media_pool then return false, "无法获取媒体池" end
    local original_playhead_timecode = capture_timeline_playhead_timecode(timeline)
    local function finish_rebuild(result, err)
        restore_timeline_playhead_timecode(timeline, original_playhead_timecode)
        return result, err
    end

    local ensured_items, ensure_err = ensure_subtitle_track_exists(TARGET_SUBTITLE_TRACK, timeline)
    if not ensured_items then return finish_rebuild(false, ensure_err or "目标字幕轨准备失败") end
    unlock_all_subtitle_tracks(timeline)
    local isolate_ok, isolate_err = isolate_subtitle_target_track(TARGET_SUBTITLE_TRACK, timeline)
    if not isolate_ok then return finish_rebuild(false, isolate_err or "无法切换到目标字幕轨") end

    local rebuild_srt_path = temp_dir() .. "/GeneratedSelection_Rebuild_" .. os.time() .. "_" .. tostring(math.random(100000, 999999)) .. ".srt"
    local write_ok, write_err = write_rows_to_rebuild_srt(rebuild_srt_path, rows, fps, base_frame)
    if not write_ok then return finish_rebuild(false, write_err) end

    local items, import_err = import_rebuild_srt_with_retry(media_pool, rebuild_srt_path)
    if not items then
        return finish_rebuild(false, import_err)
    end

    local clear_ok, clear_result = clear_subtitle_track_clips(timeline, TARGET_SUBTITLE_TRACK)
    if not clear_ok then return finish_rebuild(false, clear_result) end
    print("[SubFix Generate] 已重建目标字幕轨，清空旧字幕 " .. tostring(clear_result or 0) .. " 条，保留选区外字幕")
    print("[SubFix Generate] SRT 时间已按 timeline_start_frame 转相对时间")
    local media_pool_item = items[1]
    local append_ok, append_err = append_rebuild_srt_to_timeline(media_pool, media_pool_item)
    if not append_ok then
        return finish_rebuild(false, append_err)
    end
    cleanup_imported_subtitle_media_item(media_pool, media_pool_item, "生成选区字幕")
    print("[SubFix Generate] 已提交写回目标字幕轨 " .. tostring(TARGET_SUBTITLE_TRACK) .. "，SRT 行数 " .. tostring(#rows))
    return finish_rebuild(true)
end

local function generate_selection_subtitles()
    print("[SubFix Generate] 开始生成选区字幕")
    local resolve_obj = get_resolve()
    if not resolve_obj then error("无法获取 Resolve") end
    local pm = resolve_obj:GetProjectManager()
    local project = pm and pm:GetCurrentProject()
    local timeline = project and project:GetCurrentTimeline()
    if not project or not timeline then error("没有打开的时间线") end
    runtime_options.project_reference_path = project_reference_path(project)

    local fps = parse_fps(timeline:GetSetting("timelineFrameRate"))
    local scope, scope_err = read_generation_scope(timeline, fps)
    if not scope or scope.mode ~= WORK_SCOPE_MODE_SELECTION then
        error(scope_err or "无法确定字幕生成范围")
    end
    print(string.format(
        "[SubFix Generate] 使用范围来源=%s 帧范围 %d-%d，时长 %.2fs%s",
        tostring(scope.source_label or scope.source or "unknown"),
        tonumber(scope.start_frame) or 0,
        tonumber(scope.end_frame) or 0,
        ((tonumber(scope.end_frame) or 0) - (tonumber(scope.start_frame) or 0)) / math.max(1, fps),
        scope.item_name and scope.item_name ~= "" and (" item=" .. tostring(scope.item_name)) or ""
    ))
    local track_items, track_err = ensure_subtitle_track_exists(TARGET_SUBTITLE_TRACK, timeline)
    if not track_items then error(track_err) end

    local audio_sources, audio_err = collect_audio_sources_for_scope(timeline, scope, fps)
    if not audio_sources then error(audio_err) end
    local raw_audio_source_count = #audio_sources
    audio_sources = build_audio_track_options_for_dialog(audio_sources)
    if raw_audio_source_count ~= #audio_sources then
        print(string.format("[SubFix Generate] 音频候选已按轨道折叠: %d -> %d", raw_audio_source_count, #audio_sources))
    end
    local selected_audio_sources = nil
    -- 模式选择下拉已移除，固定使用现场模式
    local subtitle_mode = "live"
    -- 以下缺省值仅在对话框异常/未返回时兜底；正常路径由对话框返回覆盖。
    -- 字幕长度默认标准（≤25字）；识别模型 backend 默认 Qwen 本地（DEFAULT_ASR_BACKEND=="auto"）。
    local max_chars = 25
    local backend = DEFAULT_ASR_BACKEND
    local hotwords_json = nil
    local selection_err = nil
    -- 始终弹出对话框（含只有 1 个音频候选的情形）：即便只有一条音频轨，用户也需要能
    -- 选择识别模型（Qwen/豆包）与字幕长度，故不再对单候选自动跳过弹窗、直接生成。
    while true do
        selected_audio_sources, subtitle_mode, max_chars, backend, hotwords_json, selection_err = show_audio_track_selection_dialog(audio_sources, scope, fps)
        if selection_err ~= "__subfix_model_center__" then break end
        local center_ok, center_err = open_model_center(runtime_options.model_center_focus)
        runtime_options.model_center_focus = nil
        if not center_ok then error(center_err or "无法打开模型中心") end
    end
    if not selected_audio_sources then error(selection_err or "已取消") end
    local selected_track_sources = collect_selected_track_sources(selected_audio_sources)
    if type(selected_track_sources) ~= "table" or #selected_track_sources == 0 then
        error("所选轨道没有可识别音频片段")
    end
    local raw_selected_track_source_count = #selected_track_sources
    local optimized_track_sources, source_optimization = optimize_selected_track_sources_for_generation(selected_track_sources, fps)
    selected_track_sources = optimized_track_sources or selected_track_sources
    local effective_audio_seconds = selected_sources_effective_audio_seconds(selected_track_sources, fps)
    print(string.format(
        "[SubFix Generate] 使用 %d 条音频轨；音频 %d → 去重 %d；有效音频 %s",
        #selected_audio_sources,
        raw_selected_track_source_count,
        tonumber(source_optimization and source_optimization.deduped_source_count) or #selected_track_sources,
        format_generate_audio_duration(effective_audio_seconds)
    ))
    for source_index, source in ipairs(selected_track_sources) do
        print(string.format(
            "[SubFix Generate] 片段 %d/%d: A%d #%d %s timeline=%d-%d source=%.3f-%.3fs mapping=%s channel=%s muted=%s linked_offset=%s fallback=%s",
            source_index,
            #selected_track_sources,
            tonumber(source.track_index) or 0,
            tonumber(source.item_index) or 0,
            tostring(source.file_name or source.file_path or ""),
            tonumber(source.start_frame) or 0,
            tonumber(source.end_frame) or 0,
            tonumber(source.source_start_seconds) or 0,
            tonumber(source.source_end_seconds) or 0,
            tostring(source.audio_mapping_source or ""),
            tostring(source.audio_channel_index or ""),
            tostring(source.audio_mapping_muted == true),
            tostring(source.linked_offset_samples or ""),
            tostring(source.audio_mapping_fallback_reason or "")
        ))
    end

    if runtime_options.reference_text and runtime_options.reference_text ~= "" then
        runtime_options.reference_path = os.tmpname()
        if not write_text_file(runtime_options.reference_path, runtime_options.reference_text) then
            error("无法准备本次识别的参考文稿")
        end
    end
    local progress_state, progress_err = show_generate_progress_window()
    if not progress_state then error(progress_err or "无法打开进度窗口") end

    local root = temp_dir()
    local uid = tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999))
    local json_path = root .. "/GeneratedSelection_" .. uid .. ".json"
    local srt_path = root .. "/GeneratedSelection_" .. uid .. ".srt"
    local batch_plan_path = root .. "/GeneratedSelection_" .. uid .. ".batch_plan.json"
    local audio_diag_path = json_path .. ".audio_source.json"
    local cuts_ok, cuts = pcall(collect_generation_picture_cuts, timeline, scope)
    if not write_generate_batch_plan(batch_plan_path, selected_track_sources, fps, cuts_ok and cuts or {}) then
        finish_generate_progress_window(progress_state, "失败", "无法写入批量生成计划")
        error("无法写入批量生成计划")
    end
    if write_selected_audio_source_diagnostic(audio_diag_path, selected_audio_sources, scope, source_optimization) then
        print("[SubFix Generate] 已写入音频源诊断: " .. audio_diag_path)
    end
    local helper_ok, helper_err, helper_status = run_asr_helper_batch_with_progress(
        batch_plan_path,
        srt_path,
        json_path,
        scope.timeline_start_frame,
        fps,
        progress_state,
        #selected_track_sources,
        subtitle_mode,
        max_chars,
        backend,
        hotwords_json,
        effective_audio_seconds
    )
    while not helper_ok and helper_status ~= "cancelled" and (backend == "doubao_asr" or backend == "doubao_asr_v2") and is_doubao_asr_failure(helper_err) do
        -- 进度窗口中的错误文本通常包含 Python 完整日志；隐藏它，改由明确操作的短弹窗呈现。
        pcall(function() progress_state.window:Hide() end)
        local action = show_doubao_asr_failure_action_dialog(helper_err)
        if action == "close" then break end

        if action == "local_qwen" then
            backend = DEFAULT_ASR_BACKEND
            print("[SubFix Generate] 用户选择云端失败后改用本地 Qwen")
        else
            print("[SubFix Generate] 用户选择重试豆包（云端）")
        end

        local replacement_progress, replacement_err = show_generate_progress_window()
        if not replacement_progress then
            helper_ok = false
            helper_err = replacement_err or "无法重新打开生成进度窗口"
            break
        end
        progress_state = replacement_progress
        helper_ok, helper_err, helper_status = run_asr_helper_batch_with_progress(
            batch_plan_path,
            srt_path,
            json_path,
            scope.timeline_start_frame,
            fps,
            progress_state,
            #selected_track_sources,
            subtitle_mode,
            max_chars,
            backend,
            hotwords_json,
            effective_audio_seconds
        )
    end
    if not helper_ok then
        finish_generate_progress_window(progress_state, helper_status == "cancelled" and "已取消" or "失败", helper_err)
        error(helper_err)
    end

    local function cancel_postprocess_if_requested(should_continue)
        if should_continue then return end
        finish_generate_progress_window(progress_state, "已取消", "已取消，目标字幕轨未修改")
        error("已取消")
    end

    cancel_postprocess_if_requested(update_generate_postprocess_stage(
        progress_state, "解析结果", "正在解析生成结果", 96
    ))
    local raw_generated_rows, raw_generated_err, generation_trace = parse_generated_json_subtitle_rows(json_path)
    if not raw_generated_rows then
        finish_generate_progress_window(progress_state, "失败", raw_generated_err)
        error(raw_generated_err)
    end

    cancel_postprocess_if_requested(update_generate_postprocess_stage(
        progress_state, "合并字幕", "正在合并识别结果", 97
    ))
    local priority_rows, priority_err = nil, nil
    if subtitle_mode == "live" then
        priority_rows, priority_err = merge_generated_rows_for_live_writeback(raw_generated_rows, scope)
    else
        priority_rows, priority_err = merge_generated_rows_with_track_priority(raw_generated_rows, scope)
    end
    if not priority_rows then
        finish_generate_progress_window(progress_state, "失败", priority_err)
        error(priority_err)
    end
    local generated_rows, generated_err = merge_generated_rows_for_writeback({priority_rows}, scope)
    if not generated_rows then
        finish_generate_progress_window(progress_state, "失败", generated_err)
        error(generated_err)
    end

    cancel_postprocess_if_requested(update_generate_postprocess_stage(
        progress_state, "备份字幕", "正在备份目标字幕轨", 98
    ))
    local backup_path, backup_err, existing_target_rows, backup_status = backup_target_track(
        timeline,
        TARGET_SUBTITLE_TRACK,
        fps,
        scope.timeline_start_frame,
        function(completed, total)
            local message = string.format("正在备份目标字幕轨 %d/%d", completed, total)
            update_generate_progress_window(progress_state, {
                stage = "备份字幕",
                message = message,
                progress_index = 98,
                progress_total = 100
            }, message)
            return pump_generate_progress_events(progress_state)
        end
    )
    if backup_status == "cancelled" then
        cancel_postprocess_if_requested(false)
    end
    if not existing_target_rows then
        finish_generate_progress_window(progress_state, "失败", backup_err or "无法读取目标字幕轨")
        error(backup_err or "无法读取目标字幕轨")
    end
    if backup_err then
        finish_generate_progress_window(progress_state, "失败", backup_err)
        error(backup_err)
    end
    if backup_path then
        print("[SubFix Generate] 已备份目标字幕轨: " .. backup_path)
    end

    cancel_postprocess_if_requested(update_generate_postprocess_stage(
        progress_state, "写回时间线", "正在写回字幕", 99
    ))
    -- 清空目标字幕轨后无法保证可逆，因此只在真正写回前关闭取消入口。
    set_generate_progress_cancel_enabled(progress_state, false, "写回中")
    show_writeback_progress_overlay(progress_state)
    local composite_rows = build_composite_rows_for_writeback(existing_target_rows, scope, generated_rows)
    local import_ok, import_err = rebuild_target_subtitle_track_from_rows(project, timeline, composite_rows, fps, scope.timeline_start_frame)
    if not import_ok then
        finish_generate_progress_window(progress_state, "失败", import_err)
        error(import_err)
    end
    local completion_message = scope.source == "full_timeline" and "全片字幕已生成并写回时间线" or "选区字幕已生成并写回时间线"
    if type(generation_trace) == "table" and generation_trace.run_id then
        local run_id = tostring(generation_trace.run_id)
        completion_message = completion_message .. "｜版本记录 " .. run_id:sub(1, 8)
        if generation_trace.history_status == "saved" then
            print("[SubFix Generate] 版本记录 " .. run_id .. ": " .. resolve_asr_paths().generation_history .. "/" .. run_id .. ".json")
        else
            print("[SubFix Generate] 版本历史未保存 (" .. tostring(generation_trace.history_error_type or "unknown") .. ")，本次记录仍在生成 JSON 中: " .. json_path)
        end
    end
    finish_generate_progress_window(progress_state, "完成", completion_message)
    pcall(function() progress_state.window:Hide() end)
    print("[SubFix Generate] 生成选区字幕完成，诊断: " .. audio_diag_path)
    return true
end

function SubFixGenerateSelectionCore.run(options)
    options = options or {}
    runtime_options = {script_root = options.script_root, correction_reference = options.reference_text}
    TARGET_SUBTITLE_TRACK = tonumber(options.target_subtitle_track) or 1

    local ok, err = pcall(function()
        return generate_selection_subtitles()
    end)
    if runtime_options.reference_path then os.remove(runtime_options.reference_path) end
    runtime_options = {}
    if not ok then
        print("[SubFix Generate] 失败: " .. tostring(err))
        return false, tostring(err)
    end
    return true
end

return SubFixGenerateSelectionCore
